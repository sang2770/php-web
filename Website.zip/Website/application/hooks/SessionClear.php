<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SessionClear {
    public function clear_success() {
        // Xóa flashdata 'success' khi controller được load
        $CI =& get_instance();
        // Lấy đường dẫn URI hiện tại
        $uri = $CI->uri->uri_string();
        // Kiểm tra nếu URI là 'index.php'
        if (strpos($uri, 'insert') === false && strpos($uri, 'update') === false && strpos($uri, 'delete') === false && strpos($uri, 'recyclebin') === false) {
            // Xóa flashdata nếu URI không chứa các từ khóa 'insert', 'update', hoặc 'delete'
            $CI->session->unset_userdata('success');
            $CI->session->unset_userdata('error');
        }
    }
}