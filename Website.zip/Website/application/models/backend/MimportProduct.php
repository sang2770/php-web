<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MimportProduct extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->table = $this->db->dbprefix('imports`');
    }


    // Lấy chi tiết
    public function get_import($id) {
        $this->db->where('id', $id);
        $query = $this->db->get($this->table);
        return $query->row_array();
    }

    // Lấy danh sách nhập hàng
    public function get_import_list($limit,$first) {
        $this->db->where('trash', 1);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get($this->table, $limit,$first);
        return $query->result_array();
    }

    // Thêm nhập hàng mới
    public function add_import($data) {
        return $this->db->insert('imports', $data);
    }

    // Sửa thông tin nhập hàng
    public function update_import($id, $data) {
        return $this->db->where('id', $id)->update('imports', $data);
    }

    public function update_restore($id){
        $data = array('trash' => 1);
        return $this->db->where('id', $id)->update('imports', $data);
    }

    // Xóa nhập hàng
    public function delete_import($id) {
        return $this->db->where('id', $id)->delete('imports');
    }

    public function import_count(){
        $query = $this->db->get($this->table);
        return count($query->result_array());
    }

    public function import_product_trash_count(){
        $this->db->where('trash', 0);
        $query = $this->db->get($this->table);
        return count($query->result_array());
    }

    public function get_import_trash_list($limit,$first) {
        $this->db->where('trash', 0);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get($this->table, $limit,$first);
        return $query->result_array();
    }
}

