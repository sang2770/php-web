<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {
   public function __construct()
	{
		parent::__construct();
		$this->load->model('backend/Mproduct');
		$this->load->model('backend/Mcategory');
		$this->load->model('backend/Mcontent');
		$this->load->model('backend/Mcustomer');
		$this->load->model('backend/Muser');
		$this->load->model('backend/Morders');
		$this->load->model('backend/Morderdetail');
		if(!$this->session->userdata('sessionadmin'))
		{
			redirect('admin/user/login','refresh');
		}
		$this->data['user']=$this->session->userdata('sessionadmin');
		$this->data['com']='dashboard';
	}

	public function index()
	{
		$this->data['total1']=$this->Mproduct->product_sanpham_count();
		$this->data['total2']=$this->Mcontent->content_count();
		$this->data['total3']=$this->Mcustomer->customer_count();
		$this->data['total4']=$this->Morders->orders_count();

		// // Thống kê theo năm, tháng, ngày
		$d = getdate();
		$year = $d['year'];
		$month = $d['mon'];
		$day = $d['mday'];
	
		// // Lấy dữ liệu thống kê theo năm, tháng, ngày
		$this->data['orders_day'] = $this->Morders->orders_follow_day($year.'-'.$month.'-'.$day);
		// $this->data['orders_month'] = $this->Morders->orders_follow_month($year, $month);
		// $this->data['orders_year'] = $this->Morders->orders_follow_year($year);
	
		// Lấy thông tin tổng số tiền bán ra
		$this->data['total_day'] = $this->calculate_total($this->data['orders_day']);
		// $this->data['total_month'] = $this->calculate_total($this->data['orders_month']);
		// $this->data['total_year'] = $this->calculate_total($this->data['orders_year']);

		//Thống kê - vẽ biểu đồ
		
		$this->data['view']='index';
		$this->data['title']='Hệ thống quản lý cơ sở dữ liệu';
		$this->load->view('backend/layout', $this->data);
	}

	public function update_statistics() {
		// Lấy ngày được gửi từ AJAX
		$selectedDate = $this->input->post('date');
		
		// Tách ngày để lấy ngày, tháng, năm
		$dateParts = explode('-', $selectedDate);
		$year = $dateParts[0];
		$month = $dateParts[1];
		$day = $dateParts[2];
		
		// Lấy dữ liệu thống kê theo ngày, tháng, năm
		$this->data['orders_day'] = $this->Morders->orders_follow_day($year.'-'.$month.'-'.$day);
		
		
		// Tính tổng doanh thu cho ngày, tháng, năm
		$this->data['total_day'] = $this->calculate_total($this->data['orders_day']);
		
		// Trả về kết quả để cập nhật lại dữ liệu trên giao diện
		echo json_encode(['total_day' => number_format($this->data['total_day'])]);
	}

	private function calculate_total($orders)
	{
		$total = 0;
		foreach ($orders as $order) {
			$total += $order['money'];  // Assuming 'money' is the revenue field
		}
		return $total;
	}

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/Dashboard.php */