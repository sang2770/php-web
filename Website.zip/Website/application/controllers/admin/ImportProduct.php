<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ImportProduct extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('backend/MimportProduct');  // Chỉ cần model này vì liên quan đến db_imports
    $this->load->model('backend/Mcategory');
    $this->load->model('backend/Mproduct');
    $this->load->model('backend/Muser');
    $this->load->model('backend/Morders');
    if (!$this->session->userdata('sessionadmin')) {
      redirect('admin/user/login', 'refresh');
    }
    $this->data['user'] = $this->session->userdata('sessionadmin');
    $this->data['com'] = 'importProduct';
  }

  public function index()
  {
    $this->load->library('phantrang');
    $this->load->library('session');
    $limit = 10;
    $current = $this->phantrang->PageCurrent();
    $first = $this->phantrang->PageFirst($limit, $current);
    $total = $this->MimportProduct->import_count();
    $this->data['strphantrang'] = $this->phantrang->PagePer($total, $current, $limit, $url = 'admin/importProduct');
    $this->data['list'] = $this->MimportProduct->get_import_list($limit, $first);
    $this->data['view'] = 'index';
    $this->data['title'] = 'Danh mục nhập hàng';
    $this->load->view('backend/layout', $this->data);
  }

  public function insert($id)
  {
    $this->data['categoryList'] = $this->Mcategory->category_list();
    $this->data['productList'] = $this->Mproduct->get_list();
    $user_role = $this->session->userdata('sessionadmin');
    if ($user_role['role'] == 2) {
      redirect('admin/E403/index', 'refresh');
    }

    $this->load->library('form_validation');
    $this->load->library('session');
    $this->load->library('alias');

    $this->form_validation->set_rules('quantity', 'Số lượng', 'required|integer');
    if ($id) {
      $info = $this->MimportProduct->get_import($id);
      $this->data['import_code'] = $info['import_code'];
      $this->data['product_id'] = $info['product_id'];
      $this->data['quantity'] = $info['quantity'];
      $this->data['import_date'] = date('Y-m-d', strtotime($info['import_date']));
      $this->data['image'] = $info['image'];
      $this->data['product_categoryId'] = $info['product_categoryId']; 
      $this->data['id'] = $id;
    }
    
    if ($this->form_validation->run() == TRUE) {
      $product_name = "";
      foreach ($this->Mproduct->get_list() as $key => $value) {
        if ($value['id'] == $_POST['product_id']) {
          $product_name = $value['name'];
          break;
        }
      }
      $product_categoryName = "";
      foreach ($this->Mcategory->category_list() as $key => $value) {
        if ($value['id'] == $_POST['product_categoryId']) {
          $product_categoryName = $value['name'];
          break;
        }
      }
      $mydata = array(
        'product_id' => $_POST['product_id'],
        'product_name' => $product_name,
        'import_code' => $_POST['import_code'],
        'quantity' => $_POST['quantity'],
        'import_date' => $_POST['import_date'],
        'product_categoryId' => $_POST['product_categoryId'],
        'product_categoryName' => $product_categoryName,
        'status' => 1, // Nếu có trường này
        'trash' => 1,  // Trạng thái ban đầu,
        'image' => ''
      );

      $config = array();
      $config['upload_path'] = './public/images/products/';
      $config['allowed_types'] = 'jpg|png|gif';
      $config['max_size'] = '500';
      $config['encrypt_name'] = TRUE;
      $this->load->library('upload', $config);


      if ($this->upload->do_upload('image')) {  // 'image' là tên input file trong form
          $data = $this->upload->data();  // Lấy thông tin file sau khi upload
          $mydata['image'] = $data['file_name'];  // Lưu tên file vào mảng dữ liệu sản phẩm
      } else {
        $this->session->set_flashdata('error', $this->upload->display_errors());
      }
      if ($id){
        $this->MimportProduct->update_import($id, $mydata);
        $this->session->set_flashdata('success', 'Cập nhật nhập hàng thành công');
      }else{
        $this->MimportProduct->add_import($mydata);
        $this->session->set_flashdata('success', 'Thêm nhập hàng thành công');
      }
      redirect('admin/importProduct', 'refresh');
    } else {
      $this->data['view'] = 'insert';
      $this->data['action'] = !$id ? 'add' : 'update';
      $this->load->view('backend/layout', $this->data);
    }
  }

  public function trash($id){
    $mydata= array('trash' => 0);
    $this->MimportProduct->update_import($id, $mydata);
    $this->session->set_flashdata('success', 'Xóa đơn nhập vào thùng rác thành công');
    redirect('admin/importProduct','refresh');
 }

 public function restore($id){
  $this->MimportProduct->update_restore($id);
  $this->session->set_flashdata('success', 'Khôi phục đơn nhập thành công');
  redirect('admin/importProduct/recyclebin','refresh');
}

public function delete($id){
  $this->MimportProduct->delete_import($id);
  $this->session->set_flashdata('success', 'Xóa đơn nhập thành công');
  redirect('admin/importProduct/recyclebin','refresh');
}

public function recyclebin(){
  $this->load->library('phantrang');
  $limit=10;
  $current=$this->phantrang->PageCurrent();
  $first=$this->phantrang->PageFirst($limit, $current);
  $total=$this->MimportProduct->import_product_trash_count();
  $this->data['strphantrang']=$this->phantrang->PagePer($total, $current, $limit, $url='admin/importProduct/recyclebin');
  $this->data['list']=$this->MimportProduct->get_import_trash_list($limit, $first);
  $this->data['view']='recyclebin';
  $this->data['title']='Thùng rác đơn nhập';
  $this->load->view('backend/layout', $this->data);
}

  // Các hàm khác như trash, restore, delete sẽ cần sửa lại tương tự.

}
