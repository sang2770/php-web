<footer id="footer" style='padding-bottom:80px'>
    <div class="secction-footer"></div>
  </div>
    <div class="container">
        <div class="col-xs-12 col-sm-4">
        <div class="col-xs-12 col-sm-12 col-md-1 col-lg-1 logo">
  <a href="<?php echo base_url() ?>"><img src="<?php echo base_url() ?>public/images/loho3.png"></a>
</div>
                <div class="about-store"><b>
                ㅤUY TÍN - CHẤT LƯỢNG - NHANH CHÓNG</b>
             </div>
         </div> 
             <div class="col-xs-12 col-sm-3 text-left">
            <div class="f-contact">
                <h3>Thông tin liên hệ</h3>
                <ul class="list-unstyled">
                    <li class="clearfix">
                        <i class="fa fa-map-marker"></i>
                        <span>An Thuận - HCM</span>
                    </li>
                    <li class="clearfix">
                        <i class="fa fa-phone"></i>
                        <span>0399999999</span>
                    </li>
                    <li class="clearfix">
                        <i class="fa fa-envelope"></i>
                        <span><a href="mailto:alitrumdcuoi@gmail.com">anthuan@gmail.com</a></span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-xs-12 col-sm-3 text-left">
            <h3 class="footer-title">HỖ TRỢ KHÁCH HÀNG</h3>
            <ul class="list-unstyled linklists">
                <li><a href="chinh-sach">Hướng dẫn thanh toán</a></li>          
                <li><a href="chinh-sach">Hướng dẫn đặt hàng</a></li>
                <li><a href="dieu-khoan">Điều khoản</a></li>                   
            </ul>
        </div>
        <div class="col-xs-12 col-sm-2" style=margin-top:20px>
                <ul class="list-unstyled social pull-right">
                  <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                  <li><a href="#"><i class="fab fa-youtube"></i></a></li>
              </ul>
   
</div>
</footer>