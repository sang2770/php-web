<div class="content-wrapper">
	<section class="content-header">
		<h1><i class="glyphicon glyphicon-cd"></i> Danh sách nhập hàng</h1>
		<div class="breadcrumb">
			<?php
			if($user['role']==1){
				echo '<a class="btn btn-primary btn-sm" href="'.base_url().'admin/importProduct/insert" role="button">
				<span class="glyphicon glyphicon-plus"></span> Thêm mới
				</a>';
			}
			?>
			<a class="btn btn-primary btn-sm" href="<?php echo base_url()?>admin/importProduct/recyclebin" role="button">
				<span class="glyphicon glyphicon-trash"></span> Thùng rác(<?php $total=$this->MimportProduct->import_product_trash_count(); echo $total; ?>)
			</a>
		</div>
	</section>
	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="box" id="view">
					<div class="box-header with-border">
						<!-- /.box-header -->
						<div class="box-body">
							<?php  if($this->session->flashdata('success')):?>
								<div class="row">
									<div class="alert alert-success">
										<?php echo $this->session->flashdata('success'); ?>
										<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
									</div>
								</div>
							<?php  endif;?>
							<?php  if($this->session->flashdata('error')):?>
								<div class="row">
									<div class="alert alert-error">
										<?php echo $this->session->flashdata('error'); ?>
										<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
									</div>
								</div>
							<?php  endif;?>
							<div class="row" style='padding:0px; margin:0px;'>
								<!--ND-->
								<div class="table-responsive" >
									<table class="table table-hover table-bordered">
										<thead>
											<tr>
												<th class="text-center" style="width:20px">ID</th>
                                                <th style="width:150px" class="text-center">Mã nhập hàng</th>
                                                <th class="text-center">Hình ảnh</th>
                                                <th class="text-center">Tên sản phẩm</th>
                                                <th class="text-center">Số lượng nhập</th>
                                                <th class="text-center">Ngày nhập</th>
												<th class="text-center" colspan="2">Thao tác</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($list as $row):?>
												<tr>
													<td class="text-center"><?php echo $row['id'] ?></td>
                                                    <td class="text-center" style="font-size: 16px;"><?php echo $row['import_code'] ?></td>

													<td style="width:70px">
														<img src="public/images/products/<?php echo !empty($row['image']) ? $row['image'] : 'default.png' ?>" alt="<?php echo $row['product_name'] ?>" class="img-responsive">
													</td>
                                                    <td class="text-center" style="font-size: 16px;"><?php echo $row['product_name'] ?></td>
                                                    <td class="text-center" style="font-size: 16px;"><?php echo $row['quantity'] ?></td>
                                                    <td class="text-center" style="font-size: 16px;"><?php echo $row['import_date'] ?></td>
														<?php
														if($user['role']==1){
															echo '<td class="text-center">
															<a class="btn btn-success btn-xs" href="admin/importProduct/insert/'.$row['id'].'" role = "button">
															<span class="glyphicon glyphicon-edit"></span> Sửa
															</a>
															</td>';
														}
														?>
														
														<td class="text-center">
															<a class="btn btn-danger btn-xs" href="admin/importProduct/trash/<?php echo $row['id'] ?>" onclick="return confirm('Xác nhận xóa đơn nhập này ?')" role = "button">
																<span class="glyphicon glyphicon-trash"></span> Xóa
															</a>
														</td>
													</tr>
												<?php endforeach; ?>
											</tbody>
										</table>
									</div>
									<div class="row">
										<div class="col-md-12 text-center">
											<ul class="pagination">
												<?php echo $strphantrang ?>
											</ul>
										</div>
									</div>
									<!-- /.ND -->
								</div>
							</div><!-- ./box-body -->
						</div><!-- /.box -->
					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->
			</section>
			<!-- /.content -->
		</div><!-- /.content-wrapper -->