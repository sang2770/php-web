<?php if (isset($id)) {
    echo form_open_multipart('admin/importProduct/insert/' . $id); 
} else {
    echo form_open_multipart('admin/importProduct/insert'); 
}  ?>

<div class="content-wrapper">
	
		<section class="content-header">
			<h1><i class="glyphicon glyphicon-cd"></i> Thêm đơn nhập mới</h1>
			<div class="breadcrumb">
				<button type="submit" class="btn btn-primary btn-sm">
					<span class="glyphicon glyphicon-floppy-save"></span>
					<?php echo ($action === 'update') ? 'Lưu[Cập nhật]' : 'Lưu[Thêm]'; ?>
				</button>
				<a class="btn btn-primary btn-sm" href="admin/importProduct" role="button">
					<span class="glyphicon glyphicon-remove do_nos"></span> Thoát
				</a>
			</div>
		</section>
		<!-- Main content -->
		<section class="content">
			<div class="row">
				<div class="col-md-12">
					<div class="box" id="view">
						<div class="box-body">
							<div class="form-group">
								<label>Nhập mã nhập hàng<span class="maudo">(*)</span></label>
								<input class="form-control" name="import_code" placeholder="Mã nhập hàng" type="text" value="<?php echo $import_code ?? ''; ?>">
							</div>


							<div class="form-group">
								<label>Chọn loại sản phẩm<span class="maudo">(*)</span></label>
								<select name="product_categoryId" class="form-control">
									<option value="">[--Chọn loại sản phẩm--]</option>
									<?php foreach ($categoryList as $category): ?>
										<option value="<?php echo $category['id']; ?>" <?php echo (isset($product_categoryId) && $product_categoryId == $category['id']) ? 'selected' : ''; ?>>
											<?php echo $category['name']; ?>
										</option>
									<?php endforeach; ?>
								</select>

							</div>

							<div class="form-group">
								<label>Chọn sản phẩm<span class="maudo">(*)</span></label>
								<select name="product_id" class="form-control">
									<option value="">[--Chọn sản phẩm--]</option>
									<?php foreach ($productList as $product): ?>
										<option value="<?php echo $product['id']; ?>" <?php echo (isset($product_id) && $product_id == $product['id']) ? 'selected' : ''; ?>>
											<?php echo $product['name']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>

							<div class="form-group">
								<label>Chọn ngày nhập<span class="maudo">(*)</span></label>
								<input type="date" name="import_date" class="form-control" value="<?php echo $import_date ?? ''; ?>">
							</div>

							<div class="form-group">
								<label>Nhập số lượng nhập thêm<span class="maudo">(*)</span></label>
								<input type="number" class="form-control" name="quantity" placeholder="Số lượng" min="0"
									value="<?php echo $quantity ?? ''; ?>"
									max="10000">
							</div>
							<div class="form-group">
								<label>Hình ảnh</label>
								<input type="file" id="image_list" name="image">
							</div>

						</div>
					</div><!-- /.box -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</section>
	<!-- /.content -->
</div><!-- /.content-wrapper -->