-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2024 at 03:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `db_category`
--

CREATE TABLE `db_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `level` int(2) NOT NULL,
  `parentid` int(11) NOT NULL,
  `orders` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trash` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_category`
--

INSERT INTO `db_category` (`id`, `name`, `link`, `level`, `parentid`, `orders`, `created_at`, `created_by`, `updated_at`, `updated_by`, `trash`, `status`) VALUES
(36, 'Bếp', 'bep', 1, 0, '0', '2024-11-14 08:15:20', '1', '2024-11-14 09:07:17', '1', 1, 1),
(37, 'Đồ Dùng Điện', 'do-dung-dien', 1, 0, '1', '2024-11-14 08:50:05', '1', '2024-11-14 09:03:29', '1', 1, 1),
(38, 'Bếp Từ', 'bep-tu', 2, 36, '1', '2024-11-14 09:05:30', '1', '2024-11-14 09:10:28', '1', 1, 1),
(39, 'Dụng Cụ Bếp', 'dung-cu-bep', 1, 0, '2', '2024-11-14 09:08:06', '1', '2024-11-14 09:08:06', '1', 1, 1),
(40, 'Bếp Hồng Ngoại', 'bep-hong-ngoai', 2, 36, '2', '2024-11-14 09:10:50', '1', '2024-11-14 09:10:50', '1', 1, 1),
(41, 'Nồi Cơm Điện', 'noi-com-dien', 2, 37, '0', '2024-11-14 09:13:29', '1', '2024-11-14 09:13:29', '1', 1, 1),
(42, 'Máy Ép', 'may-ep', 2, 37, '1', '2024-11-14 09:15:11', '1', '2024-11-14 09:16:01', '1', 1, 1),
(43, 'Túi Zip', 'tui-zip', 2, 39, '3', '2024-11-14 09:19:49', '1', '2024-11-14 09:19:49', '1', 1, 1),
(44, 'Đĩa', 'dia', 2, 39, '4', '2024-11-14 09:25:32', '1', '2024-11-14 09:25:32', '1', 1, 1),
(45, 'Khác', 'khac', 2, 39, '5', '2024-11-14 09:29:11', '1', '2024-11-14 09:29:11', '1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_config`
--

CREATE TABLE `db_config` (
  `id` int(11) NOT NULL,
  `mail_smtp` varchar(68) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `mail_smtp_password` varchar(100) NOT NULL COMMENT 'Password mail shop',
  `mail_noreply` varchar(68) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `priceShip` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_config`
--

INSERT INTO `db_config` (`id`, `mail_smtp`, `mail_smtp_password`, `mail_noreply`, `priceShip`, `title`, `description`) VALUES
(1, 'anthuan@gmail.com', '', '', '30000', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `db_contact`
--

CREATE TABLE `db_contact` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `created_at` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `trash` int(11) NOT NULL DEFAULT 1,
  `fullname` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_contact`
--

INSERT INTO `db_contact` (`id`, `title`, `phone`, `email`, `content`, `created_at`, `status`, `trash`, `fullname`) VALUES
(4, 'Giao hàng lâu', '0399999999', 'anthuan@gmail.com', 'Khẩu chuẩn bị của shop quá lâu', '2024/11/14', 1, 1, 'An Thuận');

-- --------------------------------------------------------

--
-- Table structure for table `db_content`
--

CREATE TABLE `db_content` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `introtext` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fulltext` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `created_by` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trash` int(1) NOT NULL DEFAULT 1,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_content`
--

INSERT INTO `db_content` (`id`, `title`, `alias`, `introtext`, `fulltext`, `img`, `created`, `created_by`, `modified`, `modified_by`, `trash`, `status`) VALUES
(12, 'Bosch mở cửa hàng trải nghiệm đồ gia dụng đầu tiên tại Việt Nam', 'bosch-mo-cua-hang-trai-nghiem-do-gia-dung-dau-tien-tai-viet-nam', 'BSH Việt Nam khai trương cửa hàng trải nghiệm đồ gia dụng Bosch đầu tiên tại Estella Place, TP HCM, ngày 20/9, đánh dấu cột mốc mới tại thị trường Việt Nam.', '<p>Cửa h&agrave;ng trải nghiệm đồ gia dụng Bosch đầu ti&ecirc;n đặt tại Trung t&acirc;m thương mại Estella Place, TP Thủ Đức. Cửa h&agrave;ng mang đến trải nghiệm phong c&aacute;ch Đức, cung cấp c&aacute;c sản phẩm cao cấp, dịch vụ tiện &iacute;ch v&agrave; chương tr&igrave;nh ưu đ&atilde;i cho kh&aacute;ch h&agrave;ng.</p>\r\n\r\n<p><img alt=\"Đại diện Bosch Home Việt Nam cắt băng khai trương cửa hàng. Ảnh: BSH\" src=\"https://i1-kinhdoanh.vnecdn.net/2024/09/23/BOSCH-7424-1727078050.png?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=7V5DjX1hGHr5EdviKG66ug\" /></p>\r\n\r\n<p>Đại diện Bosch Home Việt Nam cắt băng khai trương cửa h&agrave;ng. Ảnh:&nbsp;<em>BSH</em></p>\r\n\r\n<p>Chia sẻ tại buổi lễ khai trương, &ocirc;ng Regel Stefan - Gi&aacute;m đốc BSH Việt Nam cho biết: cửa h&agrave;ng đồ gia dụng Bosch sẽ mang đến những trải nghiệm ch&acirc;n thực nhất cho người mua. Nh&atilde;n h&agrave;ng cam kết mang lại trải nghiệm độc đ&aacute;o v&agrave; ho&agrave;n to&agrave;n mới, chẳng hạn như khu vực bếp &quot;sẵn s&agrave;ng cho gia đ&igrave;nh&quot; - nơi c&aacute;c sản phẩm ti&ecirc;n tiến nhất của Bosch được t&iacute;ch hợp sẵn v&agrave;o kh&ocirc;ng gian bếp thực tế. &Ocirc;ng Stefan cũng nhấn mạnh kh&aacute;ch h&agrave;ng sẽ c&oacute; cơ hội trải nghiệm c&aacute;c c&ocirc;ng nghệ rửa b&aacute;t v&agrave; sấy kh&ocirc; mới nhất c&ugrave;ng c&aacute;c giải ph&aacute;p giặt sấy th&ocirc;ng minh.</p>\r\n\r\n<p><img alt=\"Ông Regel Stefan - Giám đốc BSH Việt Nam phát biểu tại lễ khai trương. Ảnh: BSH\" src=\"https://i1-kinhdoanh.vnecdn.net/2024/09/23/BSH-1232-1727078050.png?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=dB8K5R8bXQZoCxHARnFJDg\" /></p>\r\n\r\n<p>&Ocirc;ng Regel Stefan - Gi&aacute;m đốc BSH Việt Nam ph&aacute;t biểu tại lễ khai trương. Ảnh:&nbsp;<em>BSH</em></p>\r\n\r\n<p>Sự kiện khai trương k&eacute;o d&agrave;i từ 20 đến 22/9 mang đến nhiều hoạt động trải nghiệm th&uacute; vị. Bosch tạo n&ecirc;n kh&ocirc;ng kh&iacute; s&ocirc;i động th&ocirc;ng qua c&aacute;c hoạt động giới thiệu sản phẩm v&agrave; tương t&aacute;c trực tiếp. C&aacute;c buổi phỏng vấn kh&aacute;ch tham dự cũng mang lại những phản hồi t&iacute;ch cực, gi&uacute;p thương hiệu th&ecirc;m gần gũi với người ti&ecirc;u d&ugrave;ng Việt Nam.</p>\r\n\r\n<p>Buổi khai trương c&ograve;n c&oacute; sự tham gia của đầu bếp nổi tiếng Huy Trần. &Ocirc;ng đ&atilde; tr&igrave;nh diễn nấu ăn bằng c&aacute;c thiết bị bếp cao cấp từ Bosch. Kh&aacute;ch tham quan trực tiếp sử dụng v&agrave; trải nghiệm ba sản phẩm b&aacute;n chạy nhất của h&atilde;ng gồm m&aacute;y pha c&agrave; ph&ecirc;, m&aacute;y h&uacute;t bụi v&agrave; m&aacute;y &eacute;p chậm. Nh&atilde;n h&agrave;ng cũng tổ chức chương tr&igrave;nh r&uacute;t thăm tr&uacute;ng thưởng với c&aacute;c phần qu&agrave; gi&aacute; trị d&agrave;nh cho kh&aacute;ch h&agrave;ng may mắn..</p>\r\n\r\n<p><img alt=\"Đầu bếp Huy Trần tham gia trải nghiệm và nấu nướng tại showroom. Ảnh: BSH\" src=\"https://i1-kinhdoanh.vnecdn.net/2024/09/23/Huy-Tran-7612-1727078051.png?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=Z3Dz7iGtmMIb7GHqO4zZEg\" /></p>\r\n\r\n<p>Đầu bếp Huy Trần tham gia trải nghiệm v&agrave; nấu nướng tại showroom. Ảnh:&nbsp;<em>BSH</em></p>\r\n\r\n<p>Nh&acirc;n dịp khai trương, Bosch triển khai chương tr&igrave;nh khuyến mại với ưu đ&atilde;i giảm gi&aacute; l&ecirc;n đến 50% cho kh&aacute;ch mua h&agrave;ng v&agrave; thanh to&aacute;n trực tiếp tại cửa h&agrave;ng. Đồng thời, người d&ugrave;ng mua sắm trong những ng&agrave;y diễn ra sự kiện c&ograve;n c&oacute; cơ hội r&uacute;t thăm nhận bộ qu&agrave; tặng gi&aacute; trị. Đ&acirc;y l&agrave; cơ hội để người ti&ecirc;u d&ugrave;ng sở hữu những thiết bị gia dụng cao cấp với gi&aacute; ưu đ&atilde;i v&agrave; nhận th&ecirc;m nhiều phần qu&agrave;.</p>\r\n\r\n<p>C&aacute;c sản phẩm của Bosch được đ&aacute;nh gi&aacute; cao về t&iacute;nh thẩm mỹ, t&iacute;ch hợp nhiều t&iacute;nh năng th&ocirc;ng minh, gi&uacute;p tiết kiệm năng lượng v&agrave; tối ưu h&oacute;a hiệu suất sử dụng. V&iacute; dụ như m&aacute;y rửa ch&eacute;n với c&ocirc;ng nghệ PerfectDry sử dụng Zeolith gi&uacute;p b&aacute;t đĩa kh&ocirc; nhanh v&agrave; sạch sẽ ngay cả với c&aacute;c vật dụng bằng nhựa. D&ograve;ng m&aacute;y giặt Bosch với t&iacute;nh năng I-Dos tự động điều chỉnh lượng nước giặt ph&ugrave; hợp gi&uacute;p tiết kiệm t&agrave;i nguy&ecirc;n.</p>\r\n\r\n<p>Thương hiệu c&ograve;n ch&uacute; trọng đến dịch vụ chăm s&oacute;c kh&aacute;ch h&agrave;ng. Mọi sản phẩm của h&atilde;ng đều đi k&egrave;m với chế độ bảo h&agrave;nh v&agrave; hỗ trợ hậu m&atilde;i, đảm bảo người ti&ecirc;u d&ugrave;ng lu&ocirc;n an t&acirc;m trong qu&aacute; tr&igrave;nh sử dụng. Đội ngũ nh&acirc;n vi&ecirc;n tại cửa h&agrave;ng được đ&agrave;o tạo, sẵn s&agrave;ng tư vấn v&agrave; giải đ&aacute;p thắc mắc về c&aacute;c sản phẩm.</p>\r\n\r\n<p>Với hơn 130 năm sản xuất v&agrave; ph&acirc;n phối thiết bị gia dụng chất lượng cao tr&ecirc;n to&agrave;n cầu, Bosch ti&ecirc;n phong trong ứng dụng c&ocirc;ng nghệ ti&ecirc;n tiến nhằm n&acirc;ng cao chất lượng sống. Đơn vị l&agrave; nh&agrave; cung cấp nhiều thiết bị, hướng đến trở người bạn đồng h&agrave;nh của người ti&ecirc;u d&ugrave;ng trong h&agrave;nh tr&igrave;nh hướng tới cuộc sống tiện nghi v&agrave; an to&agrave;n.</p>\r\n\r\n<p>Với cửa h&agrave;ng mới, Bosch kỳ vọng sẽ trở th&agrave;nh lựa chọn h&agrave;ng đầu của c&aacute;c gia đ&igrave;nh Việt trong việc n&acirc;ng cao chất lượng cuộc sống.</p>\r\n', 'BOSCH-7424-17270780501.png', '2024-11-14 09:39:52', '1', '2024-11-14 09:40:30', '1', 1, 1),
(13, '5 đồ dùng trong nhà không nên tiếp xúc lâu', '5-do-dung-trong-nha-khong-nen-tiep-xuc-lau', 'Nhiều vật dụng trong gia đình có thiết kế bắt mắt, giá thành rẻ nhưng nếu sử dụng lâu dài có thể gây ra những nguy cơ với sức khỏe.', '<p>Nhiều vật dụng trong gia đ&igrave;nh c&oacute; thiết kế bắt mắt, gi&aacute; th&agrave;nh rẻ nhưng nếu sử dụng l&acirc;u d&agrave;i c&oacute; thể g&acirc;y ra những nguy cơ với sức khỏe.</p>\r\n\r\n<p>Dưới đ&acirc;y l&agrave; 5 m&oacute;n đồ được cho l&agrave; c&oacute; nguy cơ mất an to&agrave;n cao.</p>\r\n\r\n<p><strong>T&uacute;i chườm n&oacute;ng cắm điện</strong></p>\r\n\r\n<p>Sản phẩm n&agrave;y được nhiều người ưa th&iacute;ch v&agrave;o m&ugrave;a lạnh. Thậm ch&iacute; n&oacute; c&ograve;n l&agrave; bảo bối của nhiều phụ nữ với t&aacute;c dụng giảm đau bụng mỗi kỳ kinh nguyệt.</p>\r\n\r\n<p><img alt=\"5 đồ dùng trong nhà không nên tiếp xúc lâu\" src=\"https://i1-giadinh.vnecdn.net/2024/09/17/vat-2-2-1689-1726541011.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=PUzvqOgxbQbLwZkLxQh7bg\" /></p>\r\n\r\n<p><iframe frameborder=\"0\" height=\"1\" id=\"google_ads_iframe_/27973503/Vnexpress/Desktop/Inimage/Doisong/Doisong.tieudung.detail_0\" name=\"google_ads_iframe_/27973503/Vnexpress/Desktop/Inimage/Doisong/Doisong.tieudung.detail_0\" scrolling=\"no\" title=\"3rd party ad content\" width=\"1\"></iframe></p>\r\n\r\n<p>Ưu điểm của loại t&uacute;i n&agrave;y l&agrave; c&oacute; thể l&agrave;m n&oacute;ng trong v&agrave;i ph&uacute;t với thao t&aacute;c đơn giản. Tuy nhi&ecirc;n ch&uacute;ng c&oacute; nguy cơ k&eacute;m an to&agrave;n do nhiều người vừa cắm điện vừa sử dụng. Nếu t&uacute;i chườm bị hở rất dễ g&acirc;y chập điện, ch&aacute;y nổ. Cũng c&oacute; trường hợp nổ t&uacute;i do cắm điện qu&aacute; l&acirc;u, nước gi&atilde;n nở, sinh ra bọt kh&iacute;.</p>\r\n\r\n<p><strong>Giấy ăn dạng bột</strong></p>\r\n\r\n<p>Giấy ăn l&agrave; một sản phẩm thiết yếu n&ecirc;n cần đặc biệt ch&uacute; &yacute; đến chất lượng. Những loại rẻ tiền, chất lượng k&eacute;m, khi d&ugrave;ng bột giấy rơi ra chỉ với thao t&aacute;c ch&agrave; nhẹ. Nếu gặp loại giấy n&agrave;y, kh&ocirc;ng n&ecirc;n tiếp tục sử dụng bởi nhiều tạp chất, lại lạm dụng th&agrave;nh phần tẩy trắng.</p>\r\n\r\n<p>Giấy ăn dạng bột c&oacute; thể g&acirc;y dị ứng, thậm ch&iacute; g&acirc;y ra c&aacute;c vấn đề về h&ocirc; hấp.</p>\r\n\r\n<p dir=\"ltr\"><strong>D&eacute;p nhựa gi&aacute; rẻ</strong></p>\r\n\r\n<p dir=\"ltr\">Những mẫu d&eacute;p nhựa gi&aacute; rẻ thường được thiết kế bắt mắt, trở th&agrave;nh m&oacute;n đồ được nhiều người ưa d&ugrave;ng. Ngo&agrave;i chất lượng k&eacute;m, dễ hỏng r&aacute;ch, d&eacute;p nhựa gi&aacute; rẻ để l&acirc;u ng&agrave;y sẽ xuất hiện m&ugrave;i hăng nồng rồi dần thải ra c&aacute;c chất độc hại cho cơ thể.</p>\r\n\r\n<p dir=\"ltr\">Với những đ&ocirc;i d&eacute;p n&agrave;y, d&ugrave; rửa nhiều lần vẫn kh&ocirc;ng hết m&ugrave;i, thậm ch&iacute; c&oacute; thể g&acirc;y ra những triệu chứng kh&oacute; chịu ở ch&acirc;n như ngứa ng&aacute;y, nổi mẩn đỏ.</p>\r\n\r\n<p dir=\"ltr\"><strong>M&agrave;ng bọc thực phẩm</strong></p>\r\n\r\n<p dir=\"ltr\">M&agrave;ng bọc thực phẩm chủ yếu được l&agrave;m từ hợp chất polyethylene (nhựa PE) c&ugrave;ng với phụ gia h&oacute;a dẻo hay chất chống oxy h&oacute;a. Nếu sử dụng m&agrave;ng bọc thực phẩm kh&ocirc;ng đ&uacute;ng c&aacute;ch c&oacute; thể g&acirc;y hại cho sức khỏe.</p>\r\n\r\n<p>Khi bọc thức ăn bằng m&agrave;ng bọc sẽ dẫn đến sự tiếp x&uacute;c của c&aacute;c th&agrave;nh phần thực phẩm với m&agrave;ng nhựa. Trong khi h&oacute;a chất v&agrave; phụ gia l&agrave;m n&ecirc;n m&agrave;ng bọc nhựa thường c&oacute; hại cho sức khỏe.</p>\r\n\r\n<p>Người nội trợ n&ecirc;n sử dụng c&aacute;c loại hộp đựng bằng thủy tinh hoặc inox để bảo quản thực phẩm thay cho m&agrave;ng bọc, vừa th&acirc;n thiện với m&ocirc;i trường vừa tốt cho sức khỏe.</p>\r\n\r\n<p><strong>Chảo mất lớp chống d&iacute;nh</strong></p>\r\n\r\n<p>Chảo chống d&iacute;nh l&agrave; dụng cụ hỗ trợ nấu nướng hiệu quả. Tuy nhi&ecirc;n sau một thời gian, nếu lớp chống d&iacute;nh bong tr&oacute;c, những mảnh vụn kim loại nhỏ c&oacute; thể lẫn v&agrave;o thức ăn v&agrave; khi ăn v&agrave;o cơ thể kh&ocirc;ng ti&ecirc;u h&oacute;a được ch&uacute;ng.</p>\r\n', 'vat-2-2-1689-17265410112.jpg', '2024-11-14 09:41:40', '1', '2024-11-14 09:41:51', '1', 1, 1),
(14, '8 đồ gia dụng nhiều người hối hận khi mua', '8-do-gia-dung-nhieu-nguoi-hoi-han-khi-mua', 'Với sự phổ biến của các video nấu ăn ngắn, nhiều người bị ấn tượng trước các món đồ gia dụng đẹp mắt, tiện lợi nhưng thực tế ít được sử dụng trong gia đình.', '<p>Với sự phổ biến của c&aacute;c video nấu ăn ngắn, nhiều người bị ấn tượng trước c&aacute;c m&oacute;n đồ gia dụng đẹp mắt, tiện lợi nhưng thực tế &iacute;t được sử dụng trong gia đ&igrave;nh.</p>\r\n\r\n<p>Dưới đ&acirc;y l&agrave; 8 đồ gia dụng mọi người n&ecirc;n c&acirc;n nhắc kỹ về t&iacute;nh hữu dụng v&agrave; tần suất sử dụng trước khi mua kẻo l&atilde;ng ph&iacute;.</p>\r\n\r\n<p><strong>M&aacute;y &eacute;p tr&aacute;i c&acirc;y</strong></p>\r\n\r\n<p>Bạn mơ những cốc nước &eacute;p sạch sẽ, nguy&ecirc;n chất, n&ecirc;n nhiều người mới coi m&aacute;y &eacute;p tr&aacute;i c&acirc;y l&agrave; m&oacute;n đồ kh&ocirc;ng thể thiếu trong gia đ&igrave;nh.</p>\r\n\r\n<p>Ước t&iacute;nh tỷ lệ hối tiếc sau khi mua m&aacute;y &eacute;p tr&aacute;i c&acirc;y l&ecirc;n tới 90%, v&igrave; qu&aacute; kh&oacute; l&agrave;m sạch. Vết bẩn tr&ecirc;n lưỡi dao cần d&ugrave;ng b&agrave;n chải nhỏ để cọ mọi ng&oacute;c ng&aacute;ch, rất mất thời gian để c&oacute; một cốc nước uống.</p>\r\n\r\n<p>Hơn nữa nhiều người &eacute;p với tỷ lệ nguy&ecirc;n liệu kh&ocirc;ng chuẩn, vị rất tệ. V&igrave; vậy, sau khi mua m&aacute;y &eacute;p tr&aacute;i c&acirc;y, hầu hết chỉ sử dụng v&agrave;i lần rồi bỏ.</p>\r\n\r\n<p><strong>M&aacute;y l&agrave;m sữa chua</strong></p>\r\n\r\n<p>Sữa chua tự l&agrave;m vừa ngon vừa kh&ocirc;ng chứa phụ gia, gi&uacute;p tiết kiệm v&agrave; tiện lợi. Vốn dĩ n&oacute; l&agrave; một m&oacute;n đồ gia dụng gi&uacute;p gia đ&igrave;nh c&oacute; một cuộc sống tinh tế, nhưng cuối c&ugrave;ng lại th&agrave;nh r&aacute;c trong nh&agrave;.</p>\r\n\r\n<p>Để l&agrave;m sữa chua cần chuẩn bị nhiều nguy&ecirc;n liệu v&agrave; thời gian l&ecirc;n men từ 8 đến 12 giờ. V&igrave; vậy, sau khi nhiều người mua một chiếc m&aacute;y l&agrave;m sữa chua về d&ugrave;ng v&agrave;i lần, sứ mệnh của m&oacute;n đồ cơ bản đ&atilde; kết th&uacute;c.</p>\r\n\r\n<p><strong>Tủ khử tr&ugrave;ng b&aacute;t đũa</strong></p>\r\n\r\n<p>Khi nghe quảng c&aacute;o tủ khử tr&ugrave;ng b&aacute;t đũa, bạn đ&atilde; muốn rinh ngay về nh&agrave;. Nhưng chẳng được mấy bữa bạn kh&ocirc;ng c&ograve;n h&agrave;o hứng nữa. Tủ &iacute;t sử dụng dễ d&agrave;ng sinh ra vi khuẩn v&igrave; qu&aacute; ẩm. Ng&agrave;y c&agrave;ng nhiều thứ được chất v&agrave;o b&ecirc;n trong v&agrave; biến n&oacute; th&agrave;nh tủ đựng đồ. L&uacute;c n&agrave;y, bạn thậm ch&iacute; c&ograve;n kh&ocirc;ng hiểu sao m&igrave;nh c&oacute; thể mua n&oacute;.</p>\r\n\r\n<p><img alt=\"Lò nướng là thiết bị các bà nội trợ thích mua nhưng ít được sử dụng và tốn nhiều diện tích. Ảnh: Paper\" src=\"https://i1-giadinh.vnecdn.net/2024/07/16/1d704928-cfe0-46a9-abd1-e91e95-7761-9277-1721127136.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=irSDDYs72rN4dlOxINHpYA\" /></p>\r\n\r\n<p>L&ograve; nướng l&agrave; thiết bị c&aacute;c b&agrave; nội trợ th&iacute;ch mua nhưng &iacute;t được sử dụng v&agrave; tốn nhiều diện t&iacute;ch. Ảnh:<em>&nbsp;Paper</em></p>\r\n\r\n<p><strong>M&aacute;y l&agrave;m b&aacute;nh m&igrave;</strong></p>\r\n\r\n<p>Trước khi mua bạn nghĩ: H&atilde;y tự l&agrave;m b&aacute;nh m&igrave;, ngon v&agrave; tốt cho sức khỏe. Khi mua lần đầu, bạn nghĩ: T&ocirc;i c&oacute; thể tự l&agrave;m bữa s&aacute;ng v&agrave; tr&agrave; chiều. Nhưng mua l&acirc;u rồi, bạn nghĩ: Tốt nhất xuống dưới lầu ăn b&aacute;nh g&igrave; cũng c&oacute;, mới ra l&ograve; n&oacute;ng hổi.</p>\r\n\r\n<p>Đến l&uacute;c n&agrave;y, chiếc m&aacute;y cả năm kh&ocirc;ng được sử dụng. Bạn c&ograve;n nhớ 50 c&ocirc;ng thức l&agrave;m b&aacute;nh lưu tr&ecirc;n điện thoại kh&ocirc;ng?</p>\r\n\r\n<p><strong>M&aacute;y l&agrave;m sữa đậu n&agrave;nh</strong></p>\r\n\r\n<p>Sữa đậu n&agrave;nh ở qu&aacute;n vừa thơm ngậy, bạn cũng muốn l&agrave;m ở nh&agrave; n&ecirc;n đ&atilde; sắm một chiếc m&aacute;y. Hồi đầu bạn lu&acirc;n phi&ecirc;n nấu sữa đậu đỏ, đậu n&agrave;nh, m&egrave; đen. Nhưng d&ugrave; c&oacute; ngon đến mấy th&igrave; cũng đến ng&agrave;y uống ph&aacute;t ng&aacute;n.</p>\r\n\r\n<p>Hơn nữa, việc vệ sinh m&aacute;y l&agrave;m sữa đậu n&agrave;nh rất rắc rối. C&oacute; nhiều điểm m&ugrave; kh&ocirc;ng dễ l&agrave;m sạch, nếu kh&ocirc;ng cẩn thận c&oacute; thể l&agrave;m m&igrave;nh bị thương. Uống một cốc sữa đậu n&agrave;nh tốn rất nhiều thời gian v&agrave; tốt hơn hết l&uacute;c n&agrave;o th&egrave;m bạn mua một cốc về uống.</p>\r\n\r\n<p><strong>M&aacute;y h&uacute;t bụi đệm</strong></p>\r\n\r\n<p>M&aacute;y được quảng c&aacute;o h&uacute;t sạch sẽ bụi bẩn tr&ecirc;n giường, ghế sofa, thảm, quần &aacute;o v&agrave; c&aacute;c mặt h&agrave;ng dệt may kh&aacute;c. Nhưng thực tế bạn sẽ thấy thứ n&agrave;y kh&ocirc;ng hề dễ sử dụng. Chưa n&oacute;i đến t&aacute;c dụng, chỉ ri&ecirc;ng tiếng ồn v&agrave; sự mệt mỏi khi vận h&agrave;nh đ&atilde; đủ khiến bạn nản.</p>\r\n\r\n<p><strong>L&ograve; nướng</strong></p>\r\n\r\n<p>Khi một số người mua n&oacute; v&igrave; nghĩ sẽ kh&ocirc;ng bao giờ phải mua b&aacute;nh ngọt v&agrave; đồ ăn nhẹ ở cửa h&agrave;ng nữa. Tuy nhi&ecirc;n, sau khi sử dụng v&agrave;i lần, bạn bắt đầu thấy mất thời gian, rắc rối v&igrave; kh&ocirc;ng chỉ phải l&agrave;m n&oacute;ng l&ograve; trước khi sử dụng, c&ograve;n kh&oacute; l&agrave;m sạch sau khi d&ugrave;ng xong. Mỗi lần nướng mất nhiều thời gian b&agrave;y vẽ, dọn dẹp. Hơn nữa chiếc l&ograve; nướng chiếm diện t&iacute;ch kh&aacute; lớn trong bếp.</p>\r\n\r\n<p><strong>Ghế masage</strong></p>\r\n\r\n<p>Ghế massage dường như l&agrave; thiết bị cần thiết để giảm căng thẳng, mỗi mẫu đều c&oacute; tuổi thọ cao, bảo h&agrave;nh nhiều năm. Tuy nhi&ecirc;n nhiều người mua về nhận thấy d&ugrave; ghế l&agrave; h&agrave;ng thương hiệu c&oacute; t&ecirc;n tuổi, trong v&ograve;ng 1-2 năm đ&atilde; bong tr&oacute;c lớp da, qu&aacute; tr&igrave;nh sửa chữa rất rắc rối v&ocirc; t&igrave;nh biến n&oacute; trở th&agrave;nh r&aacute;c thải khổng lồ trong nh&agrave;.</p>\r\n', '1d704928-cfe0-46a9-abd1-e91e95-7761-9277-17211271362.jpg', '2024-11-14 09:42:43', '1', '2024-11-14 09:42:59', '1', 1, 1),
(15, 'Hàng nghìn người trải nghiệm ngôi nhà \'thương gia\' của Toshiba', 'hang-nghin-nguoi-trai-nghiem-ngoi-nha-thuong-gia-cua-toshiba', 'Ngày hội khám phá ngôi nhà \"thương gia\" của Toshiba tổ chức tại phố đi bộ Nguyễn Huệ dịp cuối tuần thu hút hàng nghìn người tham gia trải nghiệm và nhận quà.', '<p>Ng&agrave;y hội kh&aacute;m ph&aacute; ng&ocirc;i nh&agrave; &quot;thương gia&quot; của Toshiba tổ chức tại phố đi bộ Nguyễn Huệ dịp cuối tuần thu h&uacute;t h&agrave;ng ngh&igrave;n người tham gia trải nghiệm v&agrave; nhận qu&agrave;.</p>\r\n\r\n<p>Chương tr&igrave;nh diễn ra từ 28/6 đến 2/7 nh&acirc;n dịp kỷ niệm Ng&agrave;y Gia đ&igrave;nh Việt Nam, với nhiều hoạt động như người d&acirc;n tham quan, trải nghiệm kh&ocirc;ng gian sống &quot;thương gia&quot; với c&aacute;c sản phẩm gia dụng cao cấp đến từ Toshiba.</p>\r\n\r\n<p>Kh&ocirc;ng gian &quot;thương gia&quot; của nh&atilde;n h&agrave;ng m&ocirc; phỏng tương ứng với kh&ocirc;ng gian bếp, ph&ograve;ng kh&aacute;ch, ph&ograve;ng s&aacute;ch quen thuộc của mỗi gia đ&igrave;nh. Mỗi ph&ograve;ng được doanh nghiệp trưng b&agrave;y, giới thiệu c&aacute;c sản phẩm mới, cao cấp đến nh&atilde;n h&agrave;ng, như tủ lạnh, m&aacute;y mặt, m&aacute;y h&uacute;t bụi, m&aacute;y &eacute;p, nồi cơm điện...</p>\r\n\r\n<p><img alt=\"Người tham quan trải nghiệm không gian thương gia của Toshiba. Ảnh: Toshiba\" src=\"https://i1-giadinh.vnecdn.net/2024/06/30/a1a-5508-1719718805.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=NpLx0deH3Y-a_P4JeDluCg\" /></p>\r\n\r\n<p>Người tham quan trải nghiệm kh&ocirc;ng gian &quot;thương gia&quot; của Toshiba. Ảnh:&nbsp;<em>Toshiba</em></p>\r\n\r\n<p>Đơn cử, ph&ograve;ng kh&aacute;ch với t&ocirc;ng s&aacute;ng nhẹ nh&agrave;ng được trang bị c&aacute;c sản phẩm m&aacute;y lọc nước, m&aacute;y xay sinh tố, ấm đun si&ecirc;u tốc... để hỗ trợ người d&ugrave;ng một ng&agrave;y mới nhiều năng lượng.</p>\r\n\r\n<p><img alt=\"Khách hàng tham gia tìm hiểu sản phẩm máy lọc nước từ Toshiba. Ảnh: Toshiba\" src=\"https://i1-giadinh.vnecdn.net/2024/06/30/a1b-9933-1719718805.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=5g3MBu29Y-u9Jk65OurB3A\" /></p>\r\n\r\n<p>Kh&aacute;ch h&agrave;ng tham gia t&igrave;m hiểu sản phẩm m&aacute;y lọc nước từ Toshiba. Ảnh:&nbsp;<em>Toshiba</em></p>\r\n\r\n<p>Ph&ograve;ng s&aacute;ch thư gi&atilde;n, cho me-time (khoảng thời gian d&agrave;nh ri&ecirc;ng cho bản th&acirc;n) với m&aacute;y h&uacute;t bụi đa năng biến c&ocirc;ng việc h&agrave;ng ng&agrave;y th&agrave;nh trải nghiệm nhẹ nh&agrave;ng, đơn giản.</p>\r\n\r\n<p>Ph&ograve;ng bếp với bữa ăn ngon l&agrave;nh được chế biến nhanh, đơn giản khi c&oacute; c&aacute;c sản phẩm gia dụng bếp th&ocirc;ng minh, hỗ trợ qu&aacute; tr&igrave;nh nấu nướng, n&acirc;ng tầm bữa cơm nh&agrave; chuẩn &quot;thương gia&quot;, như nồi cơm điện, nồi chi&ecirc;n kh&ocirc;ng dầu, ấm đun nước si&ecirc;u tốc.</p>\r\n\r\n<p><img alt=\"Khách tham quan và trải nghiệm các sản phẩm gia dụng của Toshiba. Ảnh: Toshiba\" src=\"https://i1-giadinh.vnecdn.net/2024/06/30/a1c-9350-1719718805.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=QpENHJHx3Sf1AesULYIdPw\" /></p>\r\n\r\n<p>Kh&aacute;ch tham quan v&agrave; trải nghiệm c&aacute;c sản phẩm gia dụng của Toshiba. Ảnh:&nbsp;<em>Toshiba</em></p>\r\n\r\n<p>Đặc biệt, kh&aacute;ch h&agrave;ng tham gia trải nghiệm sản phẩm ở từng gian ph&ograve;ng sẽ nhận được nhiều phần qu&agrave; hấp dẫn từ chương tr&igrave;nh.</p>\r\n\r\n<p>Heo Mi Nhon - mẹ của b&eacute; Cam Cam tham gia chương tr&igrave;nh chia sẻ b&iacute; quyết khỏe đẹp mỗi ng&agrave;y l&agrave; chăm s&oacute;c bản th&acirc;n hiệu quả với c&aacute;c sản phẩm từ Toshiba. &quot;Chiều &yacute; bản th&acirc;n l&agrave; c&aacute;ch hiệu quả nhất để khỏe mạnh cả về thể chất lẫn tinh thần, từ đ&oacute; sẵn s&agrave;ng cho h&agrave;nh tr&igrave;nh chăm s&oacute;c gia đ&igrave;nh&quot;, Heo Mi Nhon cho biết.</p>\r\n\r\n<p>Với L&ecirc; H&agrave; Tr&uacute;c, c&ocirc; n&agrave;ng tiết lộ b&iacute; quyết chữa l&agrave;nh l&agrave; dọn dẹp v&agrave; tận hưởng một ng&agrave;y b&igrave;nh thường. Với sự gi&uacute;p sức từ sản phẩm m&aacute;y h&uacute;t bụi Toshiba, H&agrave; Tr&uacute;c cảm nhận t&acirc;m tr&iacute; c&oacute; thể được &quot;chữa l&agrave;nh&quot; chỉ bằng những hoạt động dọn dẹp nhỏ b&eacute; h&agrave;ng ng&agrave;y.</p>\r\n\r\n<p>Cũng tham gia sự kiện, &Ocirc;ng Anh Th&iacute;ch Nấu Ăn chia sẻ b&iacute; quyết cho bữa ăn gia đ&igrave;nh th&ecirc;m phong ph&uacute; d&ugrave; được chế biến nhanh gọn bằng những sản phẩm gia dụng đồ bếp Toshiba. Tại sự kiện, &Ocirc;ng Anh Th&iacute;ch Nấu Ăn cũng đ&atilde; k&ecirc;u gọi c&aacute;c gia đ&igrave;nh v&agrave;o hội th&ocirc;ng qua thử th&aacute;ch &quot;nấu m&oacute;n ngon đợi bố về nh&agrave;&quot; d&agrave;nh cho mẹ v&agrave; b&eacute; tham gia chương tr&igrave;nh.</p>\r\n\r\n<p>&Ocirc;ng Hồ Xu&acirc;n Lộc - Tổng gi&aacute;m đốc c&ocirc;ng ty TNHH sản phẩm ti&ecirc;u d&ugrave;ng Toshiba Việt Nam chia sẻ th&ecirc;m, Ng&agrave;y Gia đ&igrave;nh Việt Nam l&agrave; dịp đặc biệt để c&aacute;c th&agrave;nh vi&ecirc;n trong gia đ&igrave;nh quan t&acirc;m đến nhau, x&atilde; hội quan t&acirc;m đến trẻ nhỏ v&agrave; mọi c&aacute; nh&acirc;n hiểu được gi&aacute; trị m&aacute;i ấm, c&ugrave;ng nhau vượt qua s&oacute;ng gi&oacute; để c&oacute; một gia đ&igrave;nh hạnh ph&uacute;c. Nh&acirc;n dịp n&agrave;y, Toshiba Việt Nam phối hợp c&ugrave;ng Ủy ban nh&acirc;n d&acirc;n TP HCM tổ chức ng&agrave;y hội kh&aacute;m ph&aacute; ng&ocirc;i nh&agrave; &quot;Thương gia&quot;, nhằm tạo n&ecirc;n s&acirc;n chơi l&agrave;nh mạnh, lan tỏa th&ocirc;ng điệp &quot;Thương gia đ&igrave;nh, chiều &yacute; cả nh&agrave;&quot; cũng như k&iacute;ch cầu tham quan mua sắm.</p>\r\n\r\n<p><img alt=\"Ông Hồ Xuân Lộc góp mặt tại sự kiện và trải nghiệm sản phẩm. Ảnh: Toshiba\" src=\"https://i1-giadinh.vnecdn.net/2024/06/30/t01-7463-jpg-1719736675-1642-1719736822.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=VVDCJQPh0EE1ZzbYDt6HNA\" /></p>\r\n\r\n<p>&Ocirc;ng Hồ Xu&acirc;n Lộc g&oacute;p mặt tại sự kiện v&agrave; trải nghiệm sản phẩm. Ảnh:&nbsp;<em>Toshiba</em></p>\r\n\r\n<p>Sự kiện sẽ diễn ra đến hết 21h30 ng&agrave;y 2/7, với gần 10.000 qu&agrave; tặng từ nh&atilde;n h&agrave;ng c&ugrave;ng cơ hội tr&uacute;ng thưởng sản phẩm quạt m&aacute;y Comfee v&agrave; c&aacute;c sản phẩm gia dụng cao cấp kh&aacute;c.</p>\r\n', 'a1a-5508-1719718805.jpg', '2024-11-14 09:44:02', '1', '2024-11-14 09:44:16', '1', 1, 1),
(16, '7 món đồ gia dụng có thể lây truyền cảm, cúm', '7-mon-do-gia-dung-co-the-lay-truyen-cam-cum', 'Virus cảm và cúm không chỉ lây truyền trực tiếp từ người sang người mà còn có thể ẩn náu ở một số vật dụng trong nhà.\r\n\r\n', '<p>Virus cảm v&agrave; c&uacute;m kh&ocirc;ng chỉ l&acirc;y truyền trực tiếp từ người sang người m&agrave; c&ograve;n c&oacute; thể ẩn n&aacute;u ở một số vật dụng trong nh&agrave;.</p>\r\n\r\n<p>Bệnh cảm v&agrave; c&uacute;m dễ l&acirc;y truyền trực tiếp qua c&aacute;c giọt ẩm trong kh&ocirc;ng kh&iacute; khi người bệnh thở ra, n&oacute;i chuyện, ho hoặc hắt hơi. B&ecirc;n cạnh đ&oacute;, việc tiếp x&uacute;c với những đồ vật m&agrave; họ đ&atilde; chạm v&agrave;o cũng c&oacute; thể nhiễm bệnh. Dưới đ&acirc;y l&agrave; 7 đồ vật trong nh&agrave; c&oacute; thể gi&aacute;n tiếp l&acirc;y lan bệnh.</p>\r\n\r\n<p><strong>C&ocirc;ng tắc đ&egrave;n v&agrave; tay nắm cửa</strong></p>\r\n\r\n<p>Theo một nghi&ecirc;n cứu đăng tr&ecirc;n tạp ch&iacute; khoa học&nbsp;<em>Journal of Medical Virology</em>, virus thường ẩn n&aacute;u ở những nơi mọi người thường xuy&ecirc;n chạm v&agrave;o v&agrave; hiếm khi được l&agrave;m sạch, chẳng hạn như tay nắm cửa v&agrave; c&ocirc;ng tắc đ&egrave;n.</p>\r\n\r\n<p>Gia đ&igrave;nh c&acirc;n nhắc lau ch&ugrave;i c&aacute;c bề mặt hay chạm v&agrave;o trong nh&agrave; bằng chất khử tr&ugrave;ng hoặc x&agrave; ph&ograve;ng mỗi ng&agrave;y khi c&oacute; người bị ốm. Đ&acirc;y cũng l&agrave; c&aacute;ch c&oacute; thể l&agrave;m giảm nguy cơ nhiễm tr&ugrave;ng.</p>\r\n\r\n<p><strong>Cốc v&agrave; ly uống nước</strong></p>\r\n\r\n<p>Uống chung cốc hay tiếp x&uacute;c với cốc của người bị ốm cũng c&oacute; thể l&acirc;y truyền bệnh. Nghi&ecirc;n cứu đăng tr&ecirc;n tạp ch&iacute;&nbsp;<em>Dịch tễ học Mỹ</em>&nbsp;cho thấy, một nửa số người chạm tay v&agrave;o cốc c&agrave; ph&ecirc; m&agrave; những người bị cảm lạnh đ&atilde; cầm trước đ&oacute; đều bị sổ mũi. Theo Trung t&acirc;m Kiểm so&aacute;t v&agrave; Ph&ograve;ng ngừa Dịch bệnh (CDC) Mỹ, rửa tay bằng x&agrave; ph&ograve;ng v&agrave; nước l&agrave; một trong những c&aacute;ch tốt nhất để tr&aacute;nh bị l&acirc;y bệnh. Bạn h&atilde;y rửa tay trong &iacute;t nhất 20 gi&acirc;y, tương đương với thời gian h&aacute;t hai lần b&agrave;i h&aacute;t&nbsp;<em>Ch&uacute;c mừng sinh nhật</em>.</p>\r\n\r\n<p><strong>Điều khiển tivi</strong></p>\r\n\r\n<p>Điều khiển tivi l&agrave; vật dụng thường được chạm v&agrave;o nhiều nhất trong nh&agrave;. Theo Học viện B&aacute;c sĩ Gia đ&igrave;nh Mỹ, khi trong nh&agrave; c&oacute; người bị ốm, điều khiển từ xa được coi l&agrave; vật truyền ti&ecirc;u biểu của bệnh cảm lạnh v&agrave; c&uacute;m. V&igrave; vậy, điều quan trọng l&agrave; phải thường xuy&ecirc;n lau sạch đồ d&ugrave;ng n&agrave;y bằng khăn lau khử tr&ugrave;ng để loại bỏ vi khuẩn v&agrave; virus.</p>\r\n\r\n<p><img alt=\"Virus cảm lạnh và cúm dễ ẩn náu trên điều khiển tivi. Ảnh: Freepik\" src=\"https://i1-suckhoe.vnecdn.net/2023/05/09/remote-2203-1683618766.jpg?w=680&amp;h=0&amp;q=100&amp;dpr=1&amp;fit=crop&amp;s=WTCAXx27CFWd4NB0AIrwqw\" /></p>\r\n\r\n<p>Virus cảm lạnh v&agrave; c&uacute;m dễ ẩn n&aacute;u tr&ecirc;n điều khiển tivi. Ảnh:&nbsp;<em>Freepik</em></p>\r\n\r\n<p><strong>V&ograve;i rửa</strong></p>\r\n\r\n<p>Virus l&acirc;y bệnh c&oacute; thể t&iacute;ch tụ tr&ecirc;n một số vật dụng như bồn rửa, tay nắm cửa, c&ocirc;ng tắc đ&egrave;n v&agrave; v&ograve;i rửa tay. Virus cảm lạnh c&oacute; thể tồn tại tr&ecirc;n c&aacute;c bề mặt cứng, kh&ocirc;ng xốp như kim loại hoặc nhựa trong v&agrave;i ng&agrave;y v&agrave; virus c&uacute;m c&oacute; thể tồn tại tới 24 giờ. Việc để khăn lau khử tr&ugrave;ng b&ecirc;n cạnh bồn rửa để vệ sinh tay cầm thường xuy&ecirc;n cũng l&agrave; một c&aacute;ch để hạn chế l&acirc;y lan bệnh.</p>\r\n\r\n<p><strong>Khăn lau</strong></p>\r\n\r\n<p>Virus kh&oacute; tồn tại tr&ecirc;n c&aacute;c bề mặt xốp như vải hoặc khăn giấy so với tr&ecirc;n c&aacute;c bề mặt cứng, kh&ocirc;ng xốp. Tuy nhi&ecirc;n, ch&uacute;ng c&oacute; thể sống tr&ecirc;n vải ẩm trong một thời gian ngắn v&igrave; vậy đừng d&ugrave;ng chung khăn tắm hoặc khăn lau mặt với người bị ốm.</p>\r\n\r\n<p>Virus c&uacute;m c&oacute; thể tồn tại trong khoảng 15 ph&uacute;t tr&ecirc;n vật liệu mềm, virus đường&nbsp;<a href=\"https://vnexpress.net/suc-khoe/cac-benh/benh-ho-hap\" target=\"_blank\">h&ocirc; hấp</a>&nbsp;(RSV) c&oacute; thể tồn tại tới 45 ph&uacute;t v&agrave; virus g&acirc;y bệnh vi&ecirc;m thanh kh&iacute; phế quản c&oacute; thể sống tới 4 giờ tr&ecirc;n vải hoặc khăn giấy.</p>\r\n\r\n<p><strong>Gi&aacute; treo b&agrave;n chải đ&aacute;nh răng</strong></p>\r\n\r\n<p>Khi bị cảm lạnh hoặc c&uacute;m, virus sẽ b&aacute;m tr&ecirc;n bề mặt b&agrave;n chải đ&aacute;nh răng mỗi khi người bệnh cầm l&ecirc;n. Sau đ&oacute;, ch&uacute;ng c&oacute; thể lan truyền sang hộp đựng b&agrave;n chải đ&aacute;nh răng v&agrave; c&aacute;c b&agrave;n chải đ&aacute;nh răng của người kh&aacute;c. C&acirc;n nhắc để ri&ecirc;ng b&agrave;n chải đ&aacute;nh răng của người bị ốm với c&aacute;c th&agrave;nh vi&ecirc;n kh&aacute;c trong gia đ&igrave;nh.</p>\r\n\r\n<p><strong>B&uacute;t viết</strong></p>\r\n\r\n<p>Do c&aacute;c virus cảm lạnh v&agrave; c&uacute;m c&oacute; thể tồn tại tr&ecirc;n c&aacute;c bề mặt cứng như nhựa trong nhiều giờ thậm ch&iacute; nhiều ng&agrave;y n&ecirc;n b&uacute;t viết, b&uacute;t đ&aacute;nh dấu v&agrave; b&uacute;t ch&igrave; d&ugrave;ng chung trong gia đ&igrave;nh c&oacute; thể trở th&agrave;nh ổ virus. Mắt, mũi v&agrave; miệng rất dễ bị tấn c&ocirc;ng bởi nhiều loại virus cảm lạnh v&agrave; c&uacute;m th&ocirc;ng thường. Nếu kh&ocirc;ng thể nhớ rửa tay mỗi khi chạm v&agrave;o&nbsp;<a href=\"https://vnexpress.net/6-do-vat-trong-nha-co-the-gay-benh-ho-hap-4597276.html\" target=\"_blank\">đồ vật</a>&nbsp;d&ugrave;ng chung, h&atilde;y cố gắng tr&aacute;nh đưa tay l&ecirc;n mặt sau khi sử dụng b&uacute;t d&ugrave;ng chung &iacute;t nhất cho đến l&uacute;c bạn c&oacute; thể rửa tay.</p>\r\n', 'remote-2203-16836187661.jpg', '2024-11-14 09:45:17', '1', '2024-11-14 09:45:31', '1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_customer`
--

CREATE TABLE `db_customer` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `trash` int(1) NOT NULL DEFAULT 1,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_customer`
--

INSERT INTO `db_customer` (`id`, `fullname`, `username`, `password`, `address`, `phone`, `email`, `created`, `trash`, `status`) VALUES
(86, 'An Thuận', 'anthuan', 'ea34fba42a6e5b66d4414eccc0abbfc2', '', '0399999999', 'anthuan@gmail.com', '2024-11-14 00:00:00', 1, 1),
(87, 'user1', 'anthuan1', 'e10adc3949ba59abbe56e057f20f883e', '', '0123435466', 'nguyenvana@gmail.com', '2024-11-14 00:00:00', 1, 1),
(88, 'Người Dùng', 'nguoidung', 'e10adc3949ba59abbe56e057f20f883e', '', '0388988999', 'nguoidung@gmail.com', '2024-11-17 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_discount`
--

CREATE TABLE `db_discount` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `code` varchar(255) NOT NULL COMMENT 'Mã giảm giá',
  `discount` int(11) NOT NULL COMMENT 'Số tiền',
  `limit_number` int(11) NOT NULL COMMENT 'giới hạn lượt mua',
  `number_used` int(11) NOT NULL COMMENT 'Số lượng đã nhập',
  `expiration_date` date NOT NULL COMMENT 'Ngày hết hạn',
  `payment_limit` int(11) NOT NULL COMMENT 'giới hạn đơn hàng tối thiểu',
  `description` varchar(255) NOT NULL COMMENT 'Mô tả',
  `created` date NOT NULL,
  `orders` int(11) NOT NULL,
  `trash` int(1) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_discount`
--

INSERT INTO `db_discount` (`id`, `code`, `discount`, `limit_number`, `number_used`, `expiration_date`, `payment_limit`, `description`, `created`, `orders`, `trash`, `status`) VALUES
(49, 'ATSTORE', 200000, 10, 1, '2025-07-16', 1000000, '', '2024-11-14', 1, 1, 1),
(50, 'M5SURUBFBL9G', 100000, 1, 0, '2024-12-14', 0, 'Mã giảm giá 100.000 đ tự động khi đăng ký thành công', '2024-11-14', 0, 1, 1),
(51, 'IW8QMBBO3XUQ', 100000, 1, 0, '2024-12-14', 0, 'Mã giảm giá 100.000 đ tự động khi đăng ký thành công', '2024-11-14', 0, 1, 1),
(52, 'PJNRQBC6ZENO', 100000, 1, 0, '2024-12-17', 0, 'Mã giảm giá 100.000 đ tự động khi đăng ký thành công', '2024-11-17', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_district`
--

CREATE TABLE `db_district` (
  `id` int(5) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `provinceid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_district`
--

INSERT INTO `db_district` (`id`, `name`, `type`, `provinceid`) VALUES
(1, 'Quận Ba Đình', 'Quận', 1),
(2, 'Quận Hoàn Kiếm', 'Quận', 1),
(3, 'Quận Tây Hồ', 'Quận', 1),
(4, 'Quận Long Biên', 'Quận', 1),
(5, 'Quận Cầu Giấy', 'Quận', 1),
(6, 'Quận Đống Đa', 'Quận', 1),
(7, 'Quận Hai Bà Trưng', 'Quận', 1),
(8, 'Quận Hoàng Mai', 'Quận', 1),
(9, 'Quận Thanh Xuân', 'Quận', 1),
(10, 'Huyện Sóc Sơn', 'Huyện', 1),
(11, 'Huyện Đông Anh', 'Huyện', 1),
(18, 'Huyện Gia Lâm', 'Huyện', 1),
(19, 'Quận Nam Từ Liêm', 'Quận', 1),
(20, 'Huyện Thanh Trì', 'Huyện', 1),
(21, 'Quận Bắc Từ Liêm', 'Quận', 1),
(24, 'Thành phố Hà Giang', 'Thành phố', 2),
(26, 'Huyện Đồng Văn', 'Huyện', 2),
(27, 'Huyện Mèo Vạc', 'Huyện', 2),
(28, 'Huyện Yên Minh', 'Huyện', 2),
(29, 'Huyện Quản Bạ', 'Huyện', 2),
(30, 'Huyện Vị Xuyên', 'Huyện', 2),
(31, 'Huyện Bắc Mê', 'Huyện', 2),
(32, 'Huyện Hoàng Su Phì', 'Huyện', 2),
(33, 'Huyện Xín Mần', 'Huyện', 2),
(34, 'Huyện Bắc Quang', 'Huyện', 2),
(35, 'Huyện Quang Bình', 'Huyện', 2),
(40, 'Thành phố Cao Bằng', 'Thành phố', 4),
(42, 'Huyện Bảo Lâm', 'Huyện', 4),
(43, 'Huyện Bảo Lạc', 'Huyện', 4),
(44, 'Huyện Thông Nông', 'Huyện', 4),
(45, 'Huyện Hà Quảng', 'Huyện', 4),
(46, 'Huyện Trà Lĩnh', 'Huyện', 4),
(47, 'Huyện Trùng Khánh', 'Huyện', 4),
(48, 'Huyện Hạ Lang', 'Huyện', 4),
(49, 'Huyện Quảng Uyên', 'Huyện', 4),
(50, 'Huyện Phục Hoà', 'Huyện', 4),
(51, 'Huyện Hoà An', 'Huyện', 4),
(52, 'Huyện Nguyên Bình', 'Huyện', 4),
(53, 'Huyện Thạch An', 'Huyện', 4),
(58, 'Thành Phố Bắc Kạn', 'Thành phố', 6),
(60, 'Huyện Pác Nặm', 'Huyện', 6),
(61, 'Huyện Ba Bể', 'Huyện', 6),
(62, 'Huyện Ngân Sơn', 'Huyện', 6),
(63, 'Huyện Bạch Thông', 'Huyện', 6),
(64, 'Huyện Chợ Đồn', 'Huyện', 6),
(65, 'Huyện Chợ Mới', 'Huyện', 6),
(66, 'Huyện Na Rì', 'Huyện', 6),
(70, 'Thành phố Tuyên Quang', 'Thành phố', 8),
(71, 'Huyện Lâm Bình', 'Huyện', 8),
(72, 'Huyện Nà Hang', 'Huyện', 8),
(73, 'Huyện Chiêm Hóa', 'Huyện', 8),
(74, 'Huyện Hàm Yên', 'Huyện', 8),
(75, 'Huyện Yên Sơn', 'Huyện', 8),
(76, 'Huyện Sơn Dương', 'Huyện', 8),
(80, 'Thành phố Lào Cai', 'Thành phố', 10),
(82, 'Huyện Bát Xát', 'Huyện', 10),
(83, 'Huyện Mường Khương', 'Huyện', 10),
(84, 'Huyện Si Ma Cai', 'Huyện', 10),
(85, 'Huyện Bắc Hà', 'Huyện', 10),
(86, 'Huyện Bảo Thắng', 'Huyện', 10),
(87, 'Huyện Bảo Yên', 'Huyện', 10),
(88, 'Huyện Sa Pa', 'Huyện', 10),
(89, 'Huyện Văn Bàn', 'Huyện', 10),
(94, 'Thành phố Điện Biên Phủ', 'Thành phố', 11),
(95, 'Thị Xã Mường Lay', 'Thị xã', 11),
(96, 'Huyện Mường Nhé', 'Huyện', 11),
(97, 'Huyện Mường Chà', 'Huyện', 11),
(98, 'Huyện Tủa Chùa', 'Huyện', 11),
(99, 'Huyện Tuần Giáo', 'Huyện', 11),
(100, 'Huyện Điện Biên', 'Huyện', 11),
(101, 'Huyện Điện Biên Đông', 'Huyện', 11),
(102, 'Huyện Mường Ảng', 'Huyện', 11),
(103, 'Huyện Nậm Pồ', 'Huyện', 11),
(105, 'Thành phố Lai Châu', 'Thành phố', 12),
(106, 'Huyện Tam Đường', 'Huyện', 12),
(107, 'Huyện Mường Tè', 'Huyện', 12),
(108, 'Huyện Sìn Hồ', 'Huyện', 12),
(109, 'Huyện Phong Thổ', 'Huyện', 12),
(110, 'Huyện Than Uyên', 'Huyện', 12),
(111, 'Huyện Tân Uyên', 'Huyện', 12),
(112, 'Huyện Nậm Nhùn', 'Huyện', 12),
(116, 'Thành phố Sơn La', 'Thành phố', 14),
(118, 'Huyện Quỳnh Nhai', 'Huyện', 14),
(119, 'Huyện Thuận Châu', 'Huyện', 14),
(120, 'Huyện Mường La', 'Huyện', 14),
(121, 'Huyện Bắc Yên', 'Huyện', 14),
(122, 'Huyện Phù Yên', 'Huyện', 14),
(123, 'Huyện Mộc Châu', 'Huyện', 14),
(124, 'Huyện Yên Châu', 'Huyện', 14),
(125, 'Huyện Mai Sơn', 'Huyện', 14),
(126, 'Huyện Sông Mã', 'Huyện', 14),
(127, 'Huyện Sốp Cộp', 'Huyện', 14),
(128, 'Huyện Vân Hồ', 'Huyện', 14),
(132, 'Thành phố Yên Bái', 'Thành phố', 15),
(133, 'Thị xã Nghĩa Lộ', 'Thị xã', 15),
(135, 'Huyện Lục Yên', 'Huyện', 15),
(136, 'Huyện Văn Yên', 'Huyện', 15),
(137, 'Huyện Mù Căng Chải', 'Huyện', 15),
(138, 'Huyện Trấn Yên', 'Huyện', 15),
(139, 'Huyện Trạm Tấu', 'Huyện', 15),
(140, 'Huyện Văn Chấn', 'Huyện', 15),
(141, 'Huyện Yên Bình', 'Huyện', 15),
(148, 'Thành phố Hòa Bình', 'Thành phố', 17),
(150, 'Huyện Đà Bắc', 'Huyện', 17),
(151, 'Huyện Kỳ Sơn', 'Huyện', 17),
(152, 'Huyện Lương Sơn', 'Huyện', 17),
(153, 'Huyện Kim Bôi', 'Huyện', 17),
(154, 'Huyện Cao Phong', 'Huyện', 17),
(155, 'Huyện Tân Lạc', 'Huyện', 17),
(156, 'Huyện Mai Châu', 'Huyện', 17),
(157, 'Huyện Lạc Sơn', 'Huyện', 17),
(158, 'Huyện Yên Thủy', 'Huyện', 17),
(159, 'Huyện Lạc Thủy', 'Huyện', 17),
(164, 'Thành phố Thái Nguyên', 'Thành phố', 19),
(165, 'Thành phố Sông Công', 'Thành phố', 19),
(167, 'Huyện Định Hóa', 'Huyện', 19),
(168, 'Huyện Phú Lương', 'Huyện', 19),
(169, 'Huyện Đồng Hỷ', 'Huyện', 19),
(170, 'Huyện Võ Nhai', 'Huyện', 19),
(171, 'Huyện Đại Từ', 'Huyện', 19),
(172, 'Thị xã Phổ Yên', 'Thị xã', 19),
(173, 'Huyện Phú Bình', 'Huyện', 19),
(178, 'Thành phố Lạng Sơn', 'Thành phố', 20),
(180, 'Huyện Tràng Định', 'Huyện', 20),
(181, 'Huyện Bình Gia', 'Huyện', 20),
(182, 'Huyện Văn Lãng', 'Huyện', 20),
(183, 'Huyện Cao Lộc', 'Huyện', 20),
(184, 'Huyện Văn Quan', 'Huyện', 20),
(185, 'Huyện Bắc Sơn', 'Huyện', 20),
(186, 'Huyện Hữu Lũng', 'Huyện', 20),
(187, 'Huyện Chi Lăng', 'Huyện', 20),
(188, 'Huyện Lộc Bình', 'Huyện', 20),
(189, 'Huyện Đình Lập', 'Huyện', 20),
(193, 'Thành phố Hạ Long', 'Thành phố', 22),
(194, 'Thành phố Móng Cái', 'Thành phố', 22),
(195, 'Thành phố Cẩm Phả', 'Thành phố', 22),
(196, 'Thành phố Uông Bí', 'Thành phố', 22),
(198, 'Huyện Bình Liêu', 'Huyện', 22),
(199, 'Huyện Tiên Yên', 'Huyện', 22),
(200, 'Huyện Đầm Hà', 'Huyện', 22),
(201, 'Huyện Hải Hà', 'Huyện', 22),
(202, 'Huyện Ba Chẽ', 'Huyện', 22),
(203, 'Huyện Vân Đồn', 'Huyện', 22),
(204, 'Huyện Hoành Bồ', 'Huyện', 22),
(205, 'Thị xã Đông Triều', 'Thị xã', 22),
(206, 'Thị xã Quảng Yên', 'Thị xã', 22),
(207, 'Huyện Cô Tô', 'Huyện', 22),
(213, 'Thành phố Bắc Giang', 'Thành phố', 24),
(215, 'Huyện Yên Thế', 'Huyện', 24),
(216, 'Huyện Tân Yên', 'Huyện', 24),
(217, 'Huyện Lạng Giang', 'Huyện', 24),
(218, 'Huyện Lục Nam', 'Huyện', 24),
(219, 'Huyện Lục Ngạn', 'Huyện', 24),
(220, 'Huyện Sơn Động', 'Huyện', 24),
(221, 'Huyện Yên Dũng', 'Huyện', 24),
(222, 'Huyện Việt Yên', 'Huyện', 24),
(223, 'Huyện Hiệp Hòa', 'Huyện', 24),
(227, 'Thành phố Việt Trì', 'Thành phố', 25),
(228, 'Thị xã Phú Thọ', 'Thị xã', 25),
(230, 'Huyện Đoan Hùng', 'Huyện', 25),
(231, 'Huyện Hạ Hoà', 'Huyện', 25),
(232, 'Huyện Thanh Ba', 'Huyện', 25),
(233, 'Huyện Phù Ninh', 'Huyện', 25),
(234, 'Huyện Yên Lập', 'Huyện', 25),
(235, 'Huyện Cẩm Khê', 'Huyện', 25),
(236, 'Huyện Tam Nông', 'Huyện', 25),
(237, 'Huyện Lâm Thao', 'Huyện', 25),
(238, 'Huyện Thanh Sơn', 'Huyện', 25),
(239, 'Huyện Thanh Thuỷ', 'Huyện', 25),
(240, 'Huyện Tân Sơn', 'Huyện', 25),
(243, 'Thành phố Vĩnh Yên', 'Thành phố', 26),
(244, 'Thị xã Phúc Yên', 'Thị xã', 26),
(246, 'Huyện Lập Thạch', 'Huyện', 26),
(247, 'Huyện Tam Dương', 'Huyện', 26),
(248, 'Huyện Tam Đảo', 'Huyện', 26),
(249, 'Huyện Bình Xuyên', 'Huyện', 26),
(250, 'Huyện Mê Linh', 'Huyện', 1),
(251, 'Huyện Yên Lạc', 'Huyện', 26),
(252, 'Huyện Vĩnh Tường', 'Huyện', 26),
(253, 'Huyện Sông Lô', 'Huyện', 26),
(256, 'Thành phố Bắc Ninh', 'Thành phố', 27),
(258, 'Huyện Yên Phong', 'Huyện', 27),
(259, 'Huyện Quế Võ', 'Huyện', 27),
(260, 'Huyện Tiên Du', 'Huyện', 27),
(261, 'Thị xã Từ Sơn', 'Thị xã', 27),
(262, 'Huyện Thuận Thành', 'Huyện', 27),
(263, 'Huyện Gia Bình', 'Huyện', 27),
(264, 'Huyện Lương Tài', 'Huyện', 27),
(268, 'Quận Hà Đông', 'Quận', 1),
(269, 'Thị xã Sơn Tây', 'Thị xã', 1),
(271, 'Huyện Ba Vì', 'Huyện', 1),
(272, 'Huyện Phúc Thọ', 'Huyện', 1),
(273, 'Huyện Đan Phượng', 'Huyện', 1),
(274, 'Huyện Hoài Đức', 'Huyện', 1),
(275, 'Huyện Quốc Oai', 'Huyện', 1),
(276, 'Huyện Thạch Thất', 'Huyện', 1),
(277, 'Huyện Chương Mỹ', 'Huyện', 1),
(278, 'Huyện Thanh Oai', 'Huyện', 1),
(279, 'Huyện Thường Tín', 'Huyện', 1),
(280, 'Huyện Phú Xuyên', 'Huyện', 1),
(281, 'Huyện Ứng Hòa', 'Huyện', 1),
(282, 'Huyện Mỹ Đức', 'Huyện', 1),
(288, 'Thành phố Hải Dương', 'Thành phố', 30),
(290, 'Thị xã Chí Linh', 'Thị xã', 30),
(291, 'Huyện Nam Sách', 'Huyện', 30),
(292, 'Huyện Kinh Môn', 'Huyện', 30),
(293, 'Huyện Kim Thành', 'Huyện', 30),
(294, 'Huyện Thanh Hà', 'Huyện', 30),
(295, 'Huyện Cẩm Giàng', 'Huyện', 30),
(296, 'Huyện Bình Giang', 'Huyện', 30),
(297, 'Huyện Gia Lộc', 'Huyện', 30),
(298, 'Huyện Tứ Kỳ', 'Huyện', 30),
(299, 'Huyện Ninh Giang', 'Huyện', 30),
(300, 'Huyện Thanh Miện', 'Huyện', 30),
(303, 'Quận Hồng Bàng', 'Quận', 31),
(304, 'Quận Ngô Quyền', 'Quận', 31),
(305, 'Quận Lê Chân', 'Quận', 31),
(306, 'Quận Hải An', 'Quận', 31),
(307, 'Quận Kiến An', 'Quận', 31),
(308, 'Quận Đồ Sơn', 'Quận', 31),
(309, 'Quận Dương Kinh', 'Quận', 31),
(311, 'Huyện Thuỷ Nguyên', 'Huyện', 31),
(312, 'Huyện An Dương', 'Huyện', 31),
(313, 'Huyện An Lão', 'Huyện', 31),
(314, 'Huyện Kiến Thuỵ', 'Huyện', 31),
(315, 'Huyện Tiên Lãng', 'Huyện', 31),
(316, 'Huyện Vĩnh Bảo', 'Huyện', 31),
(317, 'Huyện Cát Hải', 'Huyện', 31),
(318, 'Huyện Bạch Long Vĩ', 'Huyện', 31),
(323, 'Thành phố Hưng Yên', 'Thành phố', 33),
(325, 'Huyện Văn Lâm', 'Huyện', 33),
(326, 'Huyện Văn Giang', 'Huyện', 33),
(327, 'Huyện Yên Mỹ', 'Huyện', 33),
(328, 'Huyện Mỹ Hào', 'Huyện', 33),
(329, 'Huyện Ân Thi', 'Huyện', 33),
(330, 'Huyện Khoái Châu', 'Huyện', 33),
(331, 'Huyện Kim Động', 'Huyện', 33),
(332, 'Huyện Tiên Lữ', 'Huyện', 33),
(333, 'Huyện Phù Cừ', 'Huyện', 33),
(336, 'Thành phố Thái Bình', 'Thành phố', 34),
(338, 'Huyện Quỳnh Phụ', 'Huyện', 34),
(339, 'Huyện Hưng Hà', 'Huyện', 34),
(340, 'Huyện Đông Hưng', 'Huyện', 34),
(341, 'Huyện Thái Thụy', 'Huyện', 34),
(342, 'Huyện Tiền Hải', 'Huyện', 34),
(343, 'Huyện Kiến Xương', 'Huyện', 34),
(344, 'Huyện Vũ Thư', 'Huyện', 34),
(347, 'Thành phố Phủ Lý', 'Thành phố', 35),
(349, 'Huyện Duy Tiên', 'Huyện', 35),
(350, 'Huyện Kim Bảng', 'Huyện', 35),
(351, 'Huyện Thanh Liêm', 'Huyện', 35),
(352, 'Huyện Bình Lục', 'Huyện', 35),
(353, 'Huyện Lý Nhân', 'Huyện', 35),
(356, 'Thành phố Nam Định', 'Thành phố', 36),
(358, 'Huyện Mỹ Lộc', 'Huyện', 36),
(359, 'Huyện Vụ Bản', 'Huyện', 36),
(360, 'Huyện Ý Yên', 'Huyện', 36),
(361, 'Huyện Nghĩa Hưng', 'Huyện', 36),
(362, 'Huyện Nam Trực', 'Huyện', 36),
(363, 'Huyện Trực Ninh', 'Huyện', 36),
(364, 'Huyện Xuân Trường', 'Huyện', 36),
(365, 'Huyện Giao Thủy', 'Huyện', 36),
(366, 'Huyện Hải Hậu', 'Huyện', 36),
(369, 'Thành phố Ninh Bình', 'Thành phố', 37),
(370, 'Thành phố Tam Điệp', 'Thành phố', 37),
(372, 'Huyện Nho Quan', 'Huyện', 37),
(373, 'Huyện Gia Viễn', 'Huyện', 37),
(374, 'Huyện Hoa Lư', 'Huyện', 37),
(375, 'Huyện Yên Khánh', 'Huyện', 37),
(376, 'Huyện Kim Sơn', 'Huyện', 37),
(377, 'Huyện Yên Mô', 'Huyện', 37),
(380, 'Thành phố Thanh Hóa', 'Thành phố', 38),
(381, 'Thị xã Bỉm Sơn', 'Thị xã', 38),
(382, 'Thị xã Sầm Sơn', 'Thị xã', 38),
(384, 'Huyện Mường Lát', 'Huyện', 38),
(385, 'Huyện Quan Hóa', 'Huyện', 38),
(386, 'Huyện Bá Thước', 'Huyện', 38),
(387, 'Huyện Quan Sơn', 'Huyện', 38),
(388, 'Huyện Lang Chánh', 'Huyện', 38),
(389, 'Huyện Ngọc Lặc', 'Huyện', 38),
(390, 'Huyện Cẩm Thủy', 'Huyện', 38),
(391, 'Huyện Thạch Thành', 'Huyện', 38),
(392, 'Huyện Hà Trung', 'Huyện', 38),
(393, 'Huyện Vĩnh Lộc', 'Huyện', 38),
(394, 'Huyện Yên Định', 'Huyện', 38),
(395, 'Huyện Thọ Xuân', 'Huyện', 38),
(396, 'Huyện Thường Xuân', 'Huyện', 38),
(397, 'Huyện Triệu Sơn', 'Huyện', 38),
(398, 'Huyện Thiệu Hóa', 'Huyện', 38),
(399, 'Huyện Hoằng Hóa', 'Huyện', 38),
(400, 'Huyện Hậu Lộc', 'Huyện', 38),
(401, 'Huyện Nga Sơn', 'Huyện', 38),
(402, 'Huyện Như Xuân', 'Huyện', 38),
(403, 'Huyện Như Thanh', 'Huyện', 38),
(404, 'Huyện Nông Cống', 'Huyện', 38),
(405, 'Huyện Đông Sơn', 'Huyện', 38),
(406, 'Huyện Quảng Xương', 'Huyện', 38),
(407, 'Huyện Tĩnh Gia', 'Huyện', 38),
(412, 'Thành phố Vinh', 'Thành phố', 40),
(413, 'Thị xã Cửa Lò', 'Thị xã', 40),
(414, 'Thị xã Thái Hoà', 'Thị xã', 40),
(415, 'Huyện Quế Phong', 'Huyện', 40),
(416, 'Huyện Quỳ Châu', 'Huyện', 40),
(417, 'Huyện Kỳ Sơn', 'Huyện', 40),
(418, 'Huyện Tương Dương', 'Huyện', 40),
(419, 'Huyện Nghĩa Đàn', 'Huyện', 40),
(420, 'Huyện Quỳ Hợp', 'Huyện', 40),
(421, 'Huyện Quỳnh Lưu', 'Huyện', 40),
(422, 'Huyện Con Cuông', 'Huyện', 40),
(423, 'Huyện Tân Kỳ', 'Huyện', 40),
(424, 'Huyện Anh Sơn', 'Huyện', 40),
(425, 'Huyện Diễn Châu', 'Huyện', 40),
(426, 'Huyện Yên Thành', 'Huyện', 40),
(427, 'Huyện Đô Lương', 'Huyện', 40),
(428, 'Huyện Thanh Chương', 'Huyện', 40),
(429, 'Huyện Nghi Lộc', 'Huyện', 40),
(430, 'Huyện Nam Đàn', 'Huyện', 40),
(431, 'Huyện Hưng Nguyên', 'Huyện', 40),
(432, 'Thị xã Hoàng Mai', 'Thị xã', 40),
(436, 'Thành phố Hà Tĩnh', 'Thành phố', 42),
(437, 'Thị xã Hồng Lĩnh', 'Thị xã', 42),
(439, 'Huyện Hương Sơn', 'Huyện', 42),
(440, 'Huyện Đức Thọ', 'Huyện', 42),
(441, 'Huyện Vũ Quang', 'Huyện', 42),
(442, 'Huyện Nghi Xuân', 'Huyện', 42),
(443, 'Huyện Can Lộc', 'Huyện', 42),
(444, 'Huyện Hương Khê', 'Huyện', 42),
(445, 'Huyện Thạch Hà', 'Huyện', 42),
(446, 'Huyện Cẩm Xuyên', 'Huyện', 42),
(447, 'Huyện Kỳ Anh', 'Huyện', 42),
(448, 'Huyện Lộc Hà', 'Huyện', 42),
(449, 'Thị xã Kỳ Anh', 'Thị xã', 42),
(450, 'Thành Phố Đồng Hới', 'Thành phố', 44),
(452, 'Huyện Minh Hóa', 'Huyện', 44),
(453, 'Huyện Tuyên Hóa', 'Huyện', 44),
(454, 'Huyện Quảng Trạch', 'Thị xã', 44),
(455, 'Huyện Bố Trạch', 'Huyện', 44),
(456, 'Huyện Quảng Ninh', 'Huyện', 44),
(457, 'Huyện Lệ Thủy', 'Huyện', 44),
(458, 'Thị xã Ba Đồn', 'Huyện', 44),
(461, 'Thành phố Đông Hà', 'Thành phố', 45),
(462, 'Thị xã Quảng Trị', 'Thị xã', 45),
(464, 'Huyện Vĩnh Linh', 'Huyện', 45),
(465, 'Huyện Hướng Hóa', 'Huyện', 45),
(466, 'Huyện Gio Linh', 'Huyện', 45),
(467, 'Huyện Đa Krông', 'Huyện', 45),
(468, 'Huyện Cam Lộ', 'Huyện', 45),
(469, 'Huyện Triệu Phong', 'Huyện', 45),
(470, 'Huyện Hải Lăng', 'Huyện', 45),
(471, 'Huyện Cồn Cỏ', 'Huyện', 45),
(474, 'Thành phố Huế', 'Thành phố', 46),
(476, 'Huyện Phong Điền', 'Huyện', 46),
(477, 'Huyện Quảng Điền', 'Huyện', 46),
(478, 'Huyện Phú Vang', 'Huyện', 46),
(479, 'Thị xã Hương Thủy', 'Thị xã', 46),
(480, 'Thị xã Hương Trà', 'Thị xã', 46),
(481, 'Huyện A Lưới', 'Huyện', 46),
(482, 'Huyện Phú Lộc', 'Huyện', 46),
(483, 'Huyện Nam Đông', 'Huyện', 46),
(490, 'Quận Liên Chiểu', 'Quận', 48),
(491, 'Quận Thanh Khê', 'Quận', 48),
(492, 'Quận Hải Châu', 'Quận', 48),
(493, 'Quận Sơn Trà', 'Quận', 48),
(494, 'Quận Ngũ Hành Sơn', 'Quận', 48),
(495, 'Quận Cẩm Lệ', 'Quận', 48),
(497, 'Huyện Hòa Vang', 'Huyện', 48),
(498, 'Huyện Hoàng Sa', 'Huyện', 48),
(502, 'Thành phố Tam Kỳ', 'Thành phố', 49),
(503, 'Thành phố Hội An', 'Thành phố', 49),
(504, 'Huyện Tây Giang', 'Huyện', 49),
(505, 'Huyện Đông Giang', 'Huyện', 49),
(506, 'Huyện Đại Lộc', 'Huyện', 49),
(507, 'Thị xã Điện Bàn', 'Thị xã', 49),
(508, 'Huyện Duy Xuyên', 'Huyện', 49),
(509, 'Huyện Quế Sơn', 'Huyện', 49),
(510, 'Huyện Nam Giang', 'Huyện', 49),
(511, 'Huyện Phước Sơn', 'Huyện', 49),
(512, 'Huyện Hiệp Đức', 'Huyện', 49),
(513, 'Huyện Thăng Bình', 'Huyện', 49),
(514, 'Huyện Tiên Phước', 'Huyện', 49),
(515, 'Huyện Bắc Trà My', 'Huyện', 49),
(516, 'Huyện Nam Trà My', 'Huyện', 49),
(517, 'Huyện Núi Thành', 'Huyện', 49),
(518, 'Huyện Phú Ninh', 'Huyện', 49),
(519, 'Huyện Nông Sơn', 'Huyện', 49),
(522, 'Thành phố Quảng Ngãi', 'Thành phố', 51),
(524, 'Huyện Bình Sơn', 'Huyện', 51),
(525, 'Huyện Trà Bồng', 'Huyện', 51),
(526, 'Huyện Tây Trà', 'Huyện', 51),
(527, 'Huyện Sơn Tịnh', 'Huyện', 51),
(528, 'Huyện Tư Nghĩa', 'Huyện', 51),
(529, 'Huyện Sơn Hà', 'Huyện', 51),
(530, 'Huyện Sơn Tây', 'Huyện', 51),
(531, 'Huyện Minh Long', 'Huyện', 51),
(532, 'Huyện Nghĩa Hành', 'Huyện', 51),
(533, 'Huyện Mộ Đức', 'Huyện', 51),
(534, 'Huyện Đức Phổ', 'Huyện', 51),
(535, 'Huyện Ba Tơ', 'Huyện', 51),
(536, 'Huyện Lý Sơn', 'Huyện', 51),
(540, 'Thành phố Qui Nhơn', 'Thành phố', 52),
(542, 'Huyện An Lão', 'Huyện', 52),
(543, 'Huyện Hoài Nhơn', 'Huyện', 52),
(544, 'Huyện Hoài Ân', 'Huyện', 52),
(545, 'Huyện Phù Mỹ', 'Huyện', 52),
(546, 'Huyện Vĩnh Thạnh', 'Huyện', 52),
(547, 'Huyện Tây Sơn', 'Huyện', 52),
(548, 'Huyện Phù Cát', 'Huyện', 52),
(549, 'Thị xã An Nhơn', 'Thị xã', 52),
(550, 'Huyện Tuy Phước', 'Huyện', 52),
(551, 'Huyện Vân Canh', 'Huyện', 52),
(555, 'Thành phố Tuy Hoà', 'Thành phố', 54),
(557, 'Thị xã Sông Cầu', 'Thị xã', 54),
(558, 'Huyện Đồng Xuân', 'Huyện', 54),
(559, 'Huyện Tuy An', 'Huyện', 54),
(560, 'Huyện Sơn Hòa', 'Huyện', 54),
(561, 'Huyện Sông Hinh', 'Huyện', 54),
(562, 'Huyện Tây Hoà', 'Huyện', 54),
(563, 'Huyện Phú Hoà', 'Huyện', 54),
(564, 'Huyện Đông Hòa', 'Huyện', 54),
(568, 'Thành phố Nha Trang', 'Thành phố', 56),
(569, 'Thành phố Cam Ranh', 'Thành phố', 56),
(570, 'Huyện Cam Lâm', 'Huyện', 56),
(571, 'Huyện Vạn Ninh', 'Huyện', 56),
(572, 'Thị xã Ninh Hòa', 'Thị xã', 56),
(573, 'Huyện Khánh Vĩnh', 'Huyện', 56),
(574, 'Huyện Diên Khánh', 'Huyện', 56),
(575, 'Huyện Khánh Sơn', 'Huyện', 56),
(576, 'Huyện Trường Sa', 'Huyện', 56),
(582, 'Thành phố Phan Rang-Tháp Chàm', 'Thành phố', 58),
(584, 'Huyện Bác Ái', 'Huyện', 58),
(585, 'Huyện Ninh Sơn', 'Huyện', 58),
(586, 'Huyện Ninh Hải', 'Huyện', 58),
(587, 'Huyện Ninh Phước', 'Huyện', 58),
(588, 'Huyện Thuận Bắc', 'Huyện', 58),
(589, 'Huyện Thuận Nam', 'Huyện', 58),
(593, 'Thành phố Phan Thiết', 'Thành phố', 60),
(594, 'Thị xã La Gi', 'Thị xã', 60),
(595, 'Huyện Tuy Phong', 'Huyện', 60),
(596, 'Huyện Bắc Bình', 'Huyện', 60),
(597, 'Huyện Hàm Thuận Bắc', 'Huyện', 60),
(598, 'Huyện Hàm Thuận Nam', 'Huyện', 60),
(599, 'Huyện Tánh Linh', 'Huyện', 60),
(600, 'Huyện Đức Linh', 'Huyện', 60),
(601, 'Huyện Hàm Tân', 'Huyện', 60),
(602, 'Huyện Phú Quí', 'Huyện', 60),
(608, 'Thành phố Kon Tum', 'Thành phố', 62),
(610, 'Huyện Đắk Glei', 'Huyện', 62),
(611, 'Huyện Ngọc Hồi', 'Huyện', 62),
(612, 'Huyện Đắk Tô', 'Huyện', 62),
(613, 'Huyện Kon Plông', 'Huyện', 62),
(614, 'Huyện Kon Rẫy', 'Huyện', 62),
(615, 'Huyện Đắk Hà', 'Huyện', 62),
(616, 'Huyện Sa Thầy', 'Huyện', 62),
(617, 'Huyện Tu Mơ Rông', 'Huyện', 62),
(618, 'Huyện Ia H\' Drai', 'Huyện', 62),
(622, 'Thành phố Pleiku', 'Thành phố', 64),
(623, 'Thị xã An Khê', 'Thị xã', 64),
(624, 'Thị xã Ayun Pa', 'Thị xã', 64),
(625, 'Huyện KBang', 'Huyện', 64),
(626, 'Huyện Đăk Đoa', 'Huyện', 64),
(627, 'Huyện Chư Păh', 'Huyện', 64),
(628, 'Huyện Ia Grai', 'Huyện', 64),
(629, 'Huyện Mang Yang', 'Huyện', 64),
(630, 'Huyện Kông Chro', 'Huyện', 64),
(631, 'Huyện Đức Cơ', 'Huyện', 64),
(632, 'Huyện Chư Prông', 'Huyện', 64),
(633, 'Huyện Chư Sê', 'Huyện', 64),
(634, 'Huyện Đăk Pơ', 'Huyện', 64),
(635, 'Huyện Ia Pa', 'Huyện', 64),
(637, 'Huyện Krông Pa', 'Huyện', 64),
(638, 'Huyện Phú Thiện', 'Huyện', 64),
(639, 'Huyện Chư Pưh', 'Huyện', 64),
(643, 'Thành phố Buôn Ma Thuột', 'Thành phố', 66),
(644, 'Thị Xã Buôn Hồ', 'Thị xã', 66),
(645, 'Huyện Ea H\'leo', 'Huyện', 66),
(646, 'Huyện Ea Súp', 'Huyện', 66),
(647, 'Huyện Buôn Đôn', 'Huyện', 66),
(648, 'Huyện Cư M\'gar', 'Huyện', 66),
(649, 'Huyện Krông Búk', 'Huyện', 66),
(650, 'Huyện Krông Năng', 'Huyện', 66),
(651, 'Huyện Ea Kar', 'Huyện', 66),
(652, 'Huyện M\'Đrắk', 'Huyện', 66),
(653, 'Huyện Krông Bông', 'Huyện', 66),
(654, 'Huyện Krông Pắc', 'Huyện', 66),
(655, 'Huyện Krông A Na', 'Huyện', 66),
(656, 'Huyện Lắk', 'Huyện', 66),
(657, 'Huyện Cư Kuin', 'Huyện', 66),
(660, 'Thị xã Gia Nghĩa', 'Thị xã', 67),
(661, 'Huyện Đăk Glong', 'Huyện', 67),
(662, 'Huyện Cư Jút', 'Huyện', 67),
(663, 'Huyện Đắk Mil', 'Huyện', 67),
(664, 'Huyện Krông Nô', 'Huyện', 67),
(665, 'Huyện Đắk Song', 'Huyện', 67),
(666, 'Huyện Đắk R Lấp', 'Huyện', 67),
(667, 'Huyện Tuy Đức', 'Huyện', 67),
(672, 'Thành phố Đà Lạt', 'Thành phố', 68),
(673, 'Thành phố Bảo Lộc', 'Thành phố', 68),
(674, 'Huyện Đam Rông', 'Huyện', 68),
(675, 'Huyện Lạc Dương', 'Huyện', 68),
(676, 'Huyện Lâm Hà', 'Huyện', 68),
(677, 'Huyện Đơn Dương', 'Huyện', 68),
(678, 'Huyện Đức Trọng', 'Huyện', 68),
(679, 'Huyện Di Linh', 'Huyện', 68),
(680, 'Huyện Bảo Lâm', 'Huyện', 68),
(681, 'Huyện Đạ Huoai', 'Huyện', 68),
(682, 'Huyện Đạ Tẻh', 'Huyện', 68),
(683, 'Huyện Cát Tiên', 'Huyện', 68),
(688, 'Thị xã Phước Long', 'Thị xã', 70),
(689, 'Thị xã Đồng Xoài', 'Thị xã', 70),
(690, 'Thị xã Bình Long', 'Thị xã', 70),
(691, 'Huyện Bù Gia Mập', 'Huyện', 70),
(692, 'Huyện Lộc Ninh', 'Huyện', 70),
(693, 'Huyện Bù Đốp', 'Huyện', 70),
(694, 'Huyện Hớn Quản', 'Huyện', 70),
(695, 'Huyện Đồng Phú', 'Huyện', 70),
(696, 'Huyện Bù Đăng', 'Huyện', 70),
(697, 'Huyện Chơn Thành', 'Huyện', 70),
(698, 'Huyện Phú Riềng', 'Huyện', 70),
(703, 'Thành phố Tây Ninh', 'Thành phố', 72),
(705, 'Huyện Tân Biên', 'Huyện', 72),
(706, 'Huyện Tân Châu', 'Huyện', 72),
(707, 'Huyện Dương Minh Châu', 'Huyện', 72),
(708, 'Huyện Châu Thành', 'Huyện', 72),
(709, 'Huyện Hòa Thành', 'Huyện', 72),
(710, 'Huyện Gò Dầu', 'Huyện', 72),
(711, 'Huyện Bến Cầu', 'Huyện', 72),
(712, 'Huyện Trảng Bàng', 'Huyện', 72),
(718, 'Thành phố Thủ Dầu Một', 'Thành phố', 74),
(719, 'Huyện Bàu Bàng', 'Huyện', 74),
(720, 'Huyện Dầu Tiếng', 'Huyện', 74),
(721, 'Thị xã Bến Cát', 'Thị xã', 74),
(722, 'Huyện Phú Giáo', 'Huyện', 74),
(723, 'Thị xã Tân Uyên', 'Thị xã', 74),
(724, 'Thị xã Dĩ An', 'Thị xã', 74),
(725, 'Thị xã Thuận An', 'Thị xã', 74),
(726, 'Huyện Bắc Tân Uyên', 'Huyện', 74),
(731, 'Thành phố Biên Hòa', 'Thành phố', 75),
(732, 'Thị xã Long Khánh', 'Thị xã', 75),
(734, 'Huyện Tân Phú', 'Huyện', 75),
(735, 'Huyện Vĩnh Cửu', 'Huyện', 75),
(736, 'Huyện Định Quán', 'Huyện', 75),
(737, 'Huyện Trảng Bom', 'Huyện', 75),
(738, 'Huyện Thống Nhất', 'Huyện', 75),
(739, 'Huyện Cẩm Mỹ', 'Huyện', 75),
(740, 'Huyện Long Thành', 'Huyện', 75),
(741, 'Huyện Xuân Lộc', 'Huyện', 75),
(742, 'Huyện Nhơn Trạch', 'Huyện', 75),
(747, 'Thành phố Vũng Tàu', 'Thành phố', 77),
(748, 'Thành phố Bà Rịa', 'Thành phố', 77),
(750, 'Huyện Châu Đức', 'Huyện', 77),
(751, 'Huyện Xuyên Mộc', 'Huyện', 77),
(752, 'Huyện Long Điền', 'Huyện', 77),
(753, 'Huyện Đất Đỏ', 'Huyện', 77),
(754, 'Huyện Tân Thành', 'Huyện', 77),
(755, 'Huyện Côn Đảo', 'Huyện', 77),
(760, 'Quận 1', 'Quận', 79),
(761, 'Quận 12', 'Quận', 79),
(762, 'Quận Thủ Đức', 'Quận', 79),
(763, 'Quận 9', 'Quận', 79),
(764, 'Quận Gò Vấp', 'Quận', 79),
(765, 'Quận Bình Thạnh', 'Quận', 79),
(766, 'Quận Tân Bình', 'Quận', 79),
(767, 'Quận Tân Phú', 'Quận', 79),
(768, 'Quận Phú Nhuận', 'Quận', 79),
(769, 'Quận 2', 'Quận', 79),
(770, 'Quận 3', 'Quận', 79),
(771, 'Quận 10', 'Quận', 79),
(772, 'Quận 11', 'Quận', 79),
(773, 'Quận 4', 'Quận', 79),
(774, 'Quận 5', 'Quận', 79),
(775, 'Quận 6', 'Quận', 79),
(776, 'Quận 8', 'Quận', 79),
(777, 'Quận Bình Tân', 'Quận', 79),
(778, 'Quận 7', 'Quận', 79),
(783, 'Huyện Củ Chi', 'Huyện', 79),
(784, 'Huyện Hóc Môn', 'Huyện', 79),
(785, 'Huyện Bình Chánh', 'Huyện', 79),
(786, 'Huyện Nhà Bè', 'Huyện', 79),
(787, 'Huyện Cần Giờ', 'Huyện', 79),
(794, 'Thành phố Tân An', 'Thành phố', 80),
(795, 'Thị xã Kiến Tường', 'Thị xã', 80),
(796, 'Huyện Tân Hưng', 'Huyện', 80),
(797, 'Huyện Vĩnh Hưng', 'Huyện', 80),
(798, 'Huyện Mộc Hóa', 'Huyện', 80),
(799, 'Huyện Tân Thạnh', 'Huyện', 80),
(800, 'Huyện Thạnh Hóa', 'Huyện', 80),
(801, 'Huyện Đức Huệ', 'Huyện', 80),
(802, 'Huyện Đức Hòa', 'Huyện', 80),
(803, 'Huyện Bến Lức', 'Huyện', 80),
(804, 'Huyện Thủ Thừa', 'Huyện', 80),
(805, 'Huyện Tân Trụ', 'Huyện', 80),
(806, 'Huyện Cần Đước', 'Huyện', 80),
(807, 'Huyện Cần Giuộc', 'Huyện', 80),
(808, 'Huyện Châu Thành', 'Huyện', 80),
(815, 'Thành phố Mỹ Tho', 'Thành phố', 82),
(816, 'Thị xã Gò Công', 'Thị xã', 82),
(817, 'Thị xã Cai Lậy', 'Huyện', 82),
(818, 'Huyện Tân Phước', 'Huyện', 82),
(819, 'Huyện Cái Bè', 'Huyện', 82),
(820, 'Huyện Cai Lậy', 'Thị xã', 82),
(821, 'Huyện Châu Thành', 'Huyện', 82),
(822, 'Huyện Chợ Gạo', 'Huyện', 82),
(823, 'Huyện Gò Công Tây', 'Huyện', 82),
(824, 'Huyện Gò Công Đông', 'Huyện', 82),
(825, 'Huyện Tân Phú Đông', 'Huyện', 82),
(829, 'Thành phố Bến Tre', 'Thành phố', 83),
(831, 'Huyện Châu Thành', 'Huyện', 83),
(832, 'Huyện Chợ Lách', 'Huyện', 83),
(833, 'Huyện Mỏ Cày Nam', 'Huyện', 83),
(834, 'Huyện Giồng Trôm', 'Huyện', 83),
(835, 'Huyện Bình Đại', 'Huyện', 83),
(836, 'Huyện Ba Tri', 'Huyện', 83),
(837, 'Huyện Thạnh Phú', 'Huyện', 83),
(838, 'Huyện Mỏ Cày Bắc', 'Huyện', 83),
(842, 'Thành phố Trà Vinh', 'Thành phố', 84),
(844, 'Huyện Càng Long', 'Huyện', 84),
(845, 'Huyện Cầu Kè', 'Huyện', 84),
(846, 'Huyện Tiểu Cần', 'Huyện', 84),
(847, 'Huyện Châu Thành', 'Huyện', 84),
(848, 'Huyện Cầu Ngang', 'Huyện', 84),
(849, 'Huyện Trà Cú', 'Huyện', 84),
(850, 'Huyện Duyên Hải', 'Huyện', 84),
(851, 'Thị xã Duyên Hải', 'Thị xã', 84),
(855, 'Thành phố Vĩnh Long', 'Thành phố', 86),
(857, 'Huyện Long Hồ', 'Huyện', 86),
(858, 'Huyện Mang Thít', 'Huyện', 86),
(859, 'Huyện  Vũng Liêm', 'Huyện', 86),
(860, 'Huyện Tam Bình', 'Huyện', 86),
(861, 'Thị xã Bình Minh', 'Thị xã', 86),
(862, 'Huyện Trà Ôn', 'Huyện', 86),
(863, 'Huyện Bình Tân', 'Huyện', 86),
(866, 'Thành phố Cao Lãnh', 'Thành phố', 87),
(867, 'Thành phố Sa Đéc', 'Thành phố', 87),
(868, 'Thị xã Hồng Ngự', 'Thị xã', 87),
(869, 'Huyện Tân Hồng', 'Huyện', 87),
(870, 'Huyện Hồng Ngự', 'Huyện', 87),
(871, 'Huyện Tam Nông', 'Huyện', 87),
(872, 'Huyện Tháp Mười', 'Huyện', 87),
(873, 'Huyện Cao Lãnh', 'Huyện', 87),
(874, 'Huyện Thanh Bình', 'Huyện', 87),
(875, 'Huyện Lấp Vò', 'Huyện', 87),
(876, 'Huyện Lai Vung', 'Huyện', 87),
(877, 'Huyện Châu Thành', 'Huyện', 87),
(883, 'Thành phố Long Xuyên', 'Thành phố', 89),
(884, 'Thành phố Châu Đốc', 'Thành phố', 89),
(886, 'Huyện An Phú', 'Huyện', 89),
(887, 'Thị xã Tân Châu', 'Thị xã', 89),
(888, 'Huyện Phú Tân', 'Huyện', 89),
(889, 'Huyện Châu Phú', 'Huyện', 89),
(890, 'Huyện Tịnh Biên', 'Huyện', 89),
(891, 'Huyện Tri Tôn', 'Huyện', 89),
(892, 'Huyện Châu Thành', 'Huyện', 89),
(893, 'Huyện Chợ Mới', 'Huyện', 89),
(894, 'Huyện Thoại Sơn', 'Huyện', 89),
(899, 'Thành phố Rạch Giá', 'Thành phố', 91),
(900, 'Thị xã Hà Tiên', 'Thị xã', 91),
(902, 'Huyện Kiên Lương', 'Huyện', 91),
(903, 'Huyện Hòn Đất', 'Huyện', 91),
(904, 'Huyện Tân Hiệp', 'Huyện', 91),
(905, 'Huyện Châu Thành', 'Huyện', 91),
(906, 'Huyện Giồng Riềng', 'Huyện', 91),
(907, 'Huyện Gò Quao', 'Huyện', 91),
(908, 'Huyện An Biên', 'Huyện', 91),
(909, 'Huyện An Minh', 'Huyện', 91),
(910, 'Huyện Vĩnh Thuận', 'Huyện', 91),
(911, 'Huyện Phú Quốc', 'Huyện', 91),
(912, 'Huyện Kiên Hải', 'Huyện', 91),
(913, 'Huyện U Minh Thượng', 'Huyện', 91),
(914, 'Huyện Giang Thành', 'Huyện', 91),
(916, 'Quận Ninh Kiều', 'Quận', 92),
(917, 'Quận Ô Môn', 'Quận', 92),
(918, 'Quận Bình Thuỷ', 'Quận', 92),
(919, 'Quận Cái Răng', 'Quận', 92),
(923, 'Quận Thốt Nốt', 'Quận', 92),
(924, 'Huyện Vĩnh Thạnh', 'Huyện', 92),
(925, 'Huyện Cờ Đỏ', 'Huyện', 92),
(926, 'Huyện Phong Điền', 'Huyện', 92),
(927, 'Huyện Thới Lai', 'Huyện', 92),
(930, 'Thành phố Vị Thanh', 'Thành phố', 93),
(931, 'Thị xã Ngã Bảy', 'Thị xã', 93),
(932, 'Huyện Châu Thành A', 'Huyện', 93),
(933, 'Huyện Châu Thành', 'Huyện', 93),
(934, 'Huyện Phụng Hiệp', 'Huyện', 93),
(935, 'Huyện Vị Thuỷ', 'Huyện', 93),
(936, 'Huyện Long Mỹ', 'Huyện', 93),
(937, 'Thị xã Long Mỹ', 'Thị xã', 93),
(941, 'Thành phố Sóc Trăng', 'Thành phố', 94),
(942, 'Huyện Châu Thành', 'Huyện', 94),
(943, 'Huyện Kế Sách', 'Huyện', 94),
(944, 'Huyện Mỹ Tú', 'Huyện', 94),
(945, 'Huyện Cù Lao Dung', 'Huyện', 94),
(946, 'Huyện Long Phú', 'Huyện', 94),
(947, 'Huyện Mỹ Xuyên', 'Huyện', 94),
(948, 'Thị xã Ngã Năm', 'Thị xã', 94),
(949, 'Huyện Thạnh Trị', 'Huyện', 94),
(950, 'Thị xã Vĩnh Châu', 'Thị xã', 94),
(951, 'Huyện Trần Đề', 'Huyện', 94),
(954, 'Thành phố Bạc Liêu', 'Thành phố', 95),
(956, 'Huyện Hồng Dân', 'Huyện', 95),
(957, 'Huyện Phước Long', 'Huyện', 95),
(958, 'Huyện Vĩnh Lợi', 'Huyện', 95),
(959, 'Thị xã Giá Rai', 'Thị xã', 95),
(960, 'Huyện Đông Hải', 'Huyện', 95),
(961, 'Huyện Hoà Bình', 'Huyện', 95),
(964, 'Thành phố Cà Mau', 'Thành phố', 96),
(966, 'Huyện U Minh', 'Huyện', 96),
(967, 'Huyện Thới Bình', 'Huyện', 96),
(968, 'Huyện Trần Văn Thời', 'Huyện', 96),
(969, 'Huyện Cái Nước', 'Huyện', 96),
(970, 'Huyện Đầm Dơi', 'Huyện', 96),
(971, 'Huyện Năm Căn', 'Huyện', 96),
(972, 'Huyện Phú Tân', 'Huyện', 96),
(973, 'Huyện Ngọc Hiển', 'Huyện', 96);

-- --------------------------------------------------------

--
-- Table structure for table `db_order`
--

CREATE TABLE `db_order` (
  `id` int(11) NOT NULL,
  `orderCode` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `payment_type` int(11) NOT NULL DEFAULT 2,
  `customerid` int(11) NOT NULL,
  `orderdate` datetime NOT NULL,
  `fullname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `money` int(12) NOT NULL,
  `price_ship` int(11) NOT NULL,
  `coupon` int(11) NOT NULL,
  `province` int(5) NOT NULL,
  `district` int(5) NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trash` int(1) NOT NULL DEFAULT 1,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_order`
--

INSERT INTO `db_order` (`id`, `orderCode`, `payment_type`, `customerid`, `orderdate`, `fullname`, `phone`, `money`, `price_ship`, `coupon`, `province`, `district`, `address`, `trash`, `status`) VALUES
(35, 'BrY1G3oy', 2, 86, '2024-11-14 10:43:26', 'An Thuận', '0399999999', 5054800, 30000, 0, 92, 916, 'Quan1', 1, 3),
(36, 'm6hqfbUQ', 1, 86, '2024-11-14 10:44:51', 'An Thuận', '0399999999', 1137050, 30000, 200000, 92, 916, 'Quan3', 1, 2),
(37, 'FM63iwdS', 2, 86, '2024-11-14 10:47:14', 'An Thuận', '0399999999', 7411500, 30000, 0, 92, 916, 'Quan2', 1, 2),
(38, 'ZcQ7fv0r', 2, 87, '2024-11-14 11:11:46', 'An Thuận', '0399999999', 3554800, 30000, 0, 96, 971, 'CM', 1, 0),
(39, 'jEo8iFnU', 2, 86, '2024-11-17 19:32:49', 'An Thuận', '0399999999', 3980000, 30000, 0, 92, 916, 'Quan5', 1, 2),
(40, 'm2W3QcV8', 2, 86, '2024-11-17 19:40:36', 'An Thuận', '0399999999', 1652400, 30000, 0, 92, 916, 'Quan8', 1, 2),
(41, '1Lh9cgoV', 2, 88, '2024-11-17 21:40:29', 'Người Dùng', '0388988999', 3432400, 30000, 0, 79, 760, 'HCM', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `db_orderdetail`
--

CREATE TABLE `db_orderdetail` (
  `id` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `count` int(10) NOT NULL,
  `price` int(11) NOT NULL,
  `trash` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_orderdetail`
--

INSERT INTO `db_orderdetail` (`id`, `orderid`, `productid`, `count`, `price`, `trash`, `status`) VALUES
(44, 35, 180, 2, 1622400, 1, 1),
(45, 35, 189, 1, 1780000, 1, 1),
(46, 36, 174, 1, 790000, 1, 1),
(47, 36, 198, 1, 132050, 1, 1),
(48, 36, 181, 1, 385000, 1, 1),
(49, 37, 190, 3, 2460500, 1, 1),
(50, 38, 180, 2, 1622400, 1, 1),
(51, 38, 200, 1, 280000, 1, 1),
(52, 39, 202, 5, 790000, 1, 1),
(53, 40, 180, 1, 1622400, 1, 1),
(54, 41, 180, 1, 1622400, 1, 1),
(55, 41, 189, 1, 1780000, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_producer`
--

CREATE TABLE `db_producer` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(100) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `trash` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_producer`
--

INSERT INTO `db_producer` (`id`, `name`, `code`, `keyword`, `created_at`, `created_by`, `modified`, `modified_by`, `status`, `trash`) VALUES
(12, 'Nguyễn Kim', 'nguyenkim123', 'dodungbep', '2024-11-14 08:14:49', 1, '2024-11-14 08:14:49', 1, 1, 1),
(13, 'Điện máy Xanh', 'dienmayxanh', 'dodungdien', '2024-11-14 08:49:29', 1, '2024-11-14 08:49:29', 1, 1, 1),
(14, 'Siêu thị Lotte Mart', 'sieuthi', 'dodungbep', '2024-11-14 09:21:23', 1, '2024-11-14 09:21:23', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_product`
--

CREATE TABLE `db_product` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sortDesc` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `detail` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `producer` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `number_buy` int(11) NOT NULL,
  `sale` int(3) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `price_sale` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'HDL',
  `modified` datetime NOT NULL,
  `modified_by` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'HDL',
  `trash` int(1) NOT NULL DEFAULT 1,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_product`
--

INSERT INTO `db_product` (`id`, `catid`, `name`, `alias`, `avatar`, `img`, `sortDesc`, `detail`, `producer`, `number`, `number_buy`, `sale`, `price`, `price_sale`, `created`, `created_by`, `modified`, `modified_by`, `trash`, `status`) VALUES
(166, 40, 'Bếp hồng ngoại đơn Sunhouse SHD6011', 'bep-hong-ngoai-don-sunhouse-shd6011', '32061d99280655c10ffcf4b49d6761b7.jpg', '84b9d0e2342f8b10fc1991b06c93e13e.jpg', '', '<h2>Đặc điểm nổi bật</h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai-sunhouse/\">Bếp hồng ngoại Sunhouse</a>&nbsp;c&ocirc;ng suất 2000W gi&uacute;p nấu ăn nhanh, tiết kiệm thời gian</span></li>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/doc-ngay-keo-lo-5-chat-lieu-thuong-dung-o-bep-gas.html\" target=\"_blank\">Mặt bếp k&iacute;nh cường lực</a>&nbsp;si&ecirc;u bền, chịu được nhiệt độ cao</span></li>\r\n	<li><span style=\"font-size:14px\">Sử dụng với nhiều loại nồi tạo sự thuận tiện khi nấu nướng</span></li>\r\n	<li><span style=\"font-size:14px\">Ph&iacute;m bấm tiếng Việt c&ugrave;ng&nbsp;<a href=\"https://www.nguyenkim.com/phan-biet-nhanh-gon-le-cac-loai-man-hinh-tv-tren-thi-truong-2020.html\" target=\"_blank\">m&agrave;n h&igrave;nh LED</a>&nbsp;hiển thị đa th&ocirc;ng tin</span></li>\r\n	<li><span style=\"font-size:14px\">5 chế độ nấu nướng gồm đun nước, s&uacute;p, nướng, r&aacute;n, h&acirc;m n&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Trang bị&nbsp;<a href=\"https://www.nguyenkim.com/bep-gas-va-nhung-tinh-nang-dac-biet-khong-phai-ai-cung-biet.html\">t&iacute;nh năng tự động ngắt</a>&nbsp;khi qu&aacute; nhiệt để đảm bảo an to&agrave;n</span></li>\r\n</ul>\r\n', 12, 50, 0, 50, 840000, 420000, '2024-11-14 08:28:03', '1', '2024-11-14 09:11:45', '1', 1, 1),
(167, 40, 'Bếp hồng ngoại đôi Sanaky SNK-201HGW', 'bep-hong-ngoai-doi-sanaky-snk-201hgw', '8c6f704965f5d9355facd4fafc25a07b.jpg', '4fecf53152662cb67ae1822bcf2dd439.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\">Bếp hồng ngoại đ&ocirc;i</a>&nbsp;c&oacute; thiết kế &acirc;m&nbsp;với 2 bếp tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất lớn 4000W gi&uacute;p&nbsp;nấu ăn nhanh ch&oacute;ng hơn</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt bếp k&iacute;nh chịu nhiệt đảm bảo an to&agrave;n khi sử dụng</span></li>\r\n	<li><span style=\"font-size:14px\">Sử dụng được tr&ecirc;n mọi loại nồi&nbsp;nh&ocirc;m, inox, thủy tinh, sứ</span></li>\r\n	<li><span style=\"font-size:14px\">C&oacute; hẹn giờ gi&uacute;p người d&ugrave;ng linh hoạt thời gian hơn</span></li>\r\n</ul>\r\n', 12, 30, 0, 33, 3990000, 2673300, '2024-11-14 08:31:29', '1', '2024-11-14 09:11:58', '1', 1, 1),
(168, 40, 'Bếp hồng ngoại đơn Sunhouse SHD6017', 'bep-hong-ngoai-don-sunhouse-shd6017', '581385930b6cc4a1602b07ab53169a5c.jpg', '761b2f0304f7a7f65675b88736800ad6.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 2000W chế biến thức ăn nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh&nbsp;chịu nhiệt cao cấp, si&ecirc;u bền v&agrave; dễ lau ch&ugrave;i</span></li>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai-sunhouse/\">Bếp hồng ngoại Sunhouse</a>&nbsp;kh&ocirc;ng k&eacute;n nồi, tiện lợi hơn với 5 chế độ nấu&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển cảm ứng hiện đại dễ sử dụng</span></li>\r\n	<li><span style=\"font-size:14px\">Chế độ hẹn giờ tiện lợi v&agrave; kho&aacute; an to&agrave;n</span></li>\r\n</ul>\r\n', 12, 100, 0, 24, 1490000, 1132400, '2024-11-14 08:32:54', '1', '2024-11-14 09:11:51', '1', 1, 1),
(169, 40, 'Bếp từ hồng ngoại Sunhouse SHB9104MT', 'bep-tu-hong-ngoai-sunhouse-shb9104mt', 'b9d11297ad60cff18e6c1b87ecfb3712.jpg', '8e46b191b4a391528f6f9bfe41f002ac.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Bếp điện đ&ocirc;i cho kh&ocirc;ng gian nấu ăn rộng r&atilde;i&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 4200W&nbsp;cho hiệu quả mạnh mẽ, l&agrave;m n&oacute;ng nhanh&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh&nbsp;chịu nhiệt cao cấp, si&ecirc;u bền v&agrave; dễ lau ch&ugrave;i</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển cảm ứng hiện đại</span></li>\r\n	<li><span style=\"font-size:14px\">Chế độ hẹn giờ c&ugrave;ng&nbsp;kho&aacute; an to&agrave;n tiện dụng</span></li>\r\n</ul>\r\n', 12, 50, 0, 20, 4500000, 3600000, '2024-11-14 08:34:12', '1', '2024-11-17 19:28:32', '1', 1, 1),
(170, 40, 'Bếp hồng ngoại đơn Kangaroo KG 20IFP1', 'bep-hong-ngoai-don-kangaroo-kg-20ifp1', 'c734fe97e8c774e999c7e6d2fc8f78ec.jpg', '01161c561d13f3c4e277503fe6bfdd28.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Mặt bếp bằng sứ s&aacute;ng b&oacute;ng si&ecirc;u bền, chịu nhiệt tốt, dễ vệ sinh</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 2000W gi&uacute;p nấu nhanh, tiết kiệm thời gian nấu nướng</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển n&uacute;t nhấn điện tử t&ugrave;y chỉnh nhiệt độ, dễ thao th&aacute;c</span></li>\r\n	<li><span style=\"font-size:14px\">Chức năng hẹn giờ th&ocirc;ng minh, tiết kiệm thời gian khi nội trợ</span></li>\r\n	<li><span style=\"font-size:14px\">Bếp hồng ngoại được sử dụng được cho tất cả c&aacute;c loại nồi</span></li>\r\n</ul>\r\n', 12, 40, 0, 15, 990000, 841500, '2024-11-14 08:35:10', '1', '2024-11-14 09:12:19', '1', 1, 1),
(171, 40, 'Bếp từ đơn Hayasa HA-680 Slim', 'bep-tu-don-hayasa-ha-680-slim', 'b190f7f59920eb49f467039ac0c7684c.jpg', '2ef56bae322ed9c86769649143bac1cd.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\" target=\"_blank\">Bếp từ</a>&nbsp;c&oacute; kiểu d&aacute;ng sang trọng, t&ocirc; điểm cho kh&ocirc;ng gian bếp</span></li>\r\n	<li><span style=\"font-size:14px\">Tổng c&ocirc;ng suất 2000W gi&uacute;p l&agrave;m n&oacute;ng nhanh, tiết kiệm thời gian nấu</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt bếp được l&agrave;m từ k&iacute;nh Ceramic cao cấp đảm bảo an to&agrave;n khi d&ugrave;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Trang bị nhiều t&iacute;nh năng an to&agrave;n hiện đại như tự ngắt khi qu&aacute; nhiệt, kh&oacute;a trẻ em,...</span></li>\r\n	<li><span style=\"font-size:14px\">7 chế độ nấu được c&agrave;i đặt sẵn cho bạn t&ugrave;y chỉnh theo nhu cầu</span></li>\r\n</ul>\r\n', 12, 50, 0, 32, 690000, 469200, '2024-11-14 08:36:16', '1', '2024-11-14 09:12:12', '1', 1, 1),
(172, 40, 'Bếp từ đơn Sunhouse SHD6156MT', 'bep-tu-don-sunhouse-shd6156mt', '4fe012b8ef02b2b12f3f6786cebf5509.png', '16f74ccb7742b0359ba52d8dcbd2e288.png', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\">Bếp từ đơn</a>&nbsp;kiểu d&aacute;ng gọn nhẹ, kh&ocirc;ng chiếm nhiều diện t&iacute;ch</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh chịu lực, chịu nhiệt si&ecirc;u bền v&agrave; cực kỳ chắc chắn</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 1800W đem đến hiệu suất nấu nướng nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Đa dạng chế độ nấu: Lẩu, x&agrave;o, chi&ecirc;n, s&uacute;p, hầm, hấp, giữ ấm</span></li>\r\n	<li><span style=\"font-size:14px\">T&iacute;nh năng hẹn giờ thuận tiện cho việc nấu c&aacute;c m&oacute;n như ninh, hầm</span></li>\r\n</ul>\r\n', 12, 57, 0, 40, 890000, 534000, '2024-11-14 08:37:35', '1', '2024-11-14 09:12:06', '1', 1, 1),
(173, 40, 'Bếp hồng ngoại đơn Perfect PF-BH86', 'bep-hong-ngoai-don-perfect-pf-bh86', '04bcbe465975c1e8479c91f5f3d349c6.jpg', 'f59063072d6071db7e846b6512520c4b.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\" target=\"_blank\">Bếp hồng ngoại</a>&nbsp;thiết kế tinh giản 1 v&ugrave;ng bếp, gọn nhẹ kh&ocirc;ng chiếm nhiều diện t&iacute;ch&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Th&iacute;ch hợp d&ugrave;ng cho gia đ&igrave;nh, qu&aacute;n ăn c&oacute; phục vụ lẩu, m&oacute;n ăn n&oacute;ng trực tiếp</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh Ceramic s&aacute;ng b&oacute;ng, chịu nhiệt, thẩm mỹ cao dễ d&agrave;ng lau ch&ugrave;i vệ sinh</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 2200W gi&uacute;p l&agrave;m n&oacute;ng nhanh đi k&egrave;m nhiều chế độ nấu sẵn tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển cảm ứng si&ecirc;u nhạy, chế độ hẹn giờ tiện dụng cho bạn nấu nướng</span></li>\r\n</ul>\r\n', 12, 40, 0, 0, 690000, 690000, '2024-11-14 08:38:57', '1', '2024-11-14 09:11:32', '1', 1, 1),
(174, 40, 'Bếp hồng ngoại đơn Perfect PF-BH82', 'bep-hong-ngoai-don-perfect-pf-bh82', '4bf91372040ca4f94bce92d1a80ba91c.jpg', '261b66ebfd12f8aa5aae09116e459f44.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\" target=\"_blank\">Bếp hồng ngoại</a>&nbsp;thiết kế tối giản 1 v&ugrave;ng bếp, gọn nhẹ kh&ocirc;ng chiếm nhiều diện t&iacute;ch</span></li>\r\n	<li><span style=\"font-size:14px\">Th&iacute;ch hợp d&ugrave;ng cho gia đ&igrave;nh, qu&aacute;n ăn c&oacute; phục vụ lẩu, m&oacute;n ăn n&oacute;ng trực tiếp</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh cường lực pha l&ecirc; chịu nhiệt, thẩm mỹ cao dễ d&agrave;ng lau ch&ugrave;i vệ sinh</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 2200W gi&uacute;p l&agrave;m n&oacute;ng nhanh đi k&egrave;m nhiều chế độ nấu sẵn tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển cảm ứng si&ecirc;u nhạy, chế độ hẹn giờ tiện dụng cho bạn nấu nướng</span></li>\r\n</ul>\r\n', 12, 30, 1, 0, 790000, 790000, '2024-11-14 08:39:51', '1', '2024-11-14 09:11:24', '1', 1, 1),
(175, 38, 'Bếp từ đơn Perfect PF-EC66', 'bep-tu-don-perfect-pf-ec66', '65eb644fdd7891fc4f543e714fdd05b7.jpg', 'd4cd6aff808e98f53de2ab303b97fe9c.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\" target=\"_blank\">Bếp từ</a>&nbsp;đơn kiểu d&aacute;ng gọn nhẹ, tiết kiệm diện t&iacute;ch, t&ocirc; điểm kh&ocirc;ng gian bếp</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế hiện đại v&agrave; sang trọng với m&agrave;u sắc h&agrave;i ho&agrave; với căn bếp</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh Ceramic cao cấp chịu lực, chịu nhiệt tốt, dễ d&agrave;ng lau ch&ugrave;i</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 1450W đem đến hiệu suất nấu nướng nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">M&acirc;m tải nhiệt đồng truyền nhiệt nhanh c&ugrave;ng m&agrave;n h&igrave;nh LED cảm ứng nhạy</span></li>\r\n	<li><span style=\"font-size:14px\">Hẹn giờ 4 tiếng c&ugrave;ng nhiều chế độ nấu sẵn đi k&egrave;m nấu nướng dễ d&agrave;ng hơn</span></li>\r\n</ul>\r\n', 12, 120, 0, 5, 550000, 522500, '2024-11-14 08:41:00', '1', '2024-11-14 09:11:14', '1', 1, 1),
(176, 38, 'Bếp từ đơn Funiki HSD8136', 'bep-tu-don-funiki-hsd8136', '7ebad64c2a92ac132097dadd1381916f.jpg', '2c8a42889827df0a3ef83ba4ac2104e6.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/bep-tu-hong-ngoai/\" target=\"_blank\">Bếp từ</a>&nbsp;đơn kiểu d&aacute;ng gọn nhẹ, tiết kiệm diện t&iacute;ch, t&ocirc; điểm kh&ocirc;ng gian bếp</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế hiện đại v&agrave; sang trọng với m&agrave;u sắc h&agrave;i ho&agrave; với căn bếp</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh Crystal Plate cao cấp chịu lực, chịu nhiệt tốt, dễ d&agrave;ng lau ch&ugrave;i</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 2000W đem đến hiệu suất nấu nướng nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">T&iacute;nh năng hẹn giờ 6 tiếng thuận tiện cho việc nấu c&aacute;c m&oacute;n như ninh, hầm</span></li>\r\n</ul>\r\n', 12, 40, 0, 0, 1290000, 1290000, '2024-11-14 08:43:17', '1', '2024-11-14 09:09:42', '1', 1, 1),
(177, 38, 'Bếp từ đơn Sunhouse SHD6802', 'bep-tu-don-sunhouse-shd6802', 'c0e66b0109d2adc34c6836972fbc281e.jpg', '2d0d21a6d97401b860d56e6e31c271e0.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Thiết kế nhỏ gọn với m&agrave;u đen sang trọng c&oacute; thể đặt ở mọi vị tr&iacute; trong bếp</span></li>\r\n	<li><span style=\"font-size:14px\">Bếp c&oacute; đến 8 chế độ nấu đa dạng, đ&aacute;p ứng được mọi nhu cầu nấu nướng</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh ceramic cường lực si&ecirc;u bền, dễ vệ sinh chịu được nhiệt đến 7600&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển dạng ph&iacute;m bấm bằng tiếng Việt dễ d&agrave;ng điều chỉnh v&agrave; c&agrave;i đặt&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng nghệ từ trường l&agrave;m n&oacute;ng trực tiếp đ&aacute;y nồi gi&uacute;p thức ăn ch&iacute;n nhanh hơn</span></li>\r\n	<li><span style=\"font-size:14px\">T&iacute;nh năng kh&oacute;a trẻ em đảm bảo an to&agrave;n với c&aacute;c th&agrave;nh vi&ecirc;n trong gia đ&igrave;nh bạn</span></li>\r\n</ul>\r\n', 12, 25, 0, 0, 990000, 990000, '2024-11-14 08:44:29', '1', '2024-11-14 09:09:36', '1', 1, 1),
(178, 38, 'Bếp từ đơn BlueStone ICB-6610', 'bep-tu-don-bluestone-icb-6610', '825312bc8be6f214603527a8cc3b7fde.jpg', '70cc693e865ab3d12a9f4422426a30ed.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li>T<span style=\"font-size:14px\">hiết kế bếp từ đơn gọn đẹp, kh&ocirc;ng chiếm nhiều diện t&iacute;ch</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất hoạt động 2000W cho m&oacute;n ăn đun s&ocirc;i nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt bếp bằng k&iacute;nh Ceramic cao cấp loại A s&aacute;ng b&oacute;ng, chịu lực</span></li>\r\n	<li><span style=\"font-size:14px\">Bảng điều khiển n&uacute;t bấm cơ tiếng Việt dễ sử dụng v&agrave; thao t&aacute;c</span></li>\r\n	<li><span style=\"font-size:14px\">6 chế độ nấu được c&agrave;i đặt sẵn, trang bị chế độ hẹn giờ tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Quạt tản nhiệt lớn giảm nhiệt tốt cho bếp từ, tăng tuổi thọ bếp</span></li>\r\n</ul>\r\n', 12, 20, 0, 15, 1290000, 1096500, '2024-11-14 08:45:31', '1', '2024-11-14 09:09:29', '1', 1, 1),
(179, 38, 'Bếp từ đơn Bear DCL-A22Q5', 'bep-tu-don-bear-dcl-a22q5', '682f3774d0fea616be6bccb3dae8deb7.jpg', '156bcee51c94c702bc5ff5d1dbfe3eaa.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Bếp điện đơn c&oacute; k&iacute;ch thước nhỏ gọn, thiết kế trẻ trung, thời thượng</span></li>\r\n	<li><span style=\"font-size:14px\">Bếp đa năng, d&ugrave;ng chi&ecirc;n, x&agrave;o, hầm, nấu lẩu,... v&ocirc; c&ugrave;ng tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Tổng c&ocirc;ng suất 2000W với nhiều v&ugrave;ng nấu cho bạn nấu nhiều m&oacute;n c&ugrave;ng l&uacute;c</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt bếp được l&agrave;m từ k&iacute;nh chịu nhiệt cao đảm bảo an to&agrave;n khi d&ugrave;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Điều khiển cảm ứng v&agrave; n&uacute;t vặn tiện t&ugrave;y chỉnh c&aacute;c chức năng kh&aacute;c nhau</span></li>\r\n	<li><span style=\"font-size:14px\">Hệ thống tản nhiệt đa chiều gi&uacute;p giảm tiếng ồn khi bếp hoạt động</span></li>\r\n</ul>\r\n', 12, 27, 0, 2, 490000, 480200, '2024-11-14 08:46:41', '1', '2024-11-14 09:09:05', '1', 0, 1),
(180, 38, 'Bếp từ đơn Sunhouse SHD6869', 'bep-tu-don-sunhouse-shd6869', '1f001f0edcaf05eac237ca6dd5c05aa3.jpg', '918a8c7ac5913c670819f15720a027ea.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">7 chế độ nấu c&agrave;i đặt sẵn, thoải m&aacute;i chế biến mọi m&oacute;n ăn</span></li>\r\n	<li><span style=\"font-size:14px\">Mặt k&iacute;nh ceramic cường lực chịu nhiệt, si&ecirc;u bền bỉ</span></li>\r\n	<li><span style=\"font-size:14px\">Bếp từ t&iacute;nh năng hẹn giờ tiện lợi, kh&oacute;a trẻ em an to&agrave;n</span></li>\r\n	<li><span style=\"font-size:14px\">Tự động ngắt khi qu&aacute; tải nhiệt &amp; điện, an to&agrave;n người d&ugrave;ng</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất cao 2000W qu&aacute; tr&igrave;nh gia nhiệt diễn ra nhanh hơn</span></li>\r\n</ul>\r\n', 12, 33, 2, 4, 1690000, 1622400, '2024-11-14 08:47:57', '1', '2024-11-14 09:11:00', '1', 1, 1),
(181, 41, 'Nồi cơm điện Sharp 1.8 lít KS-181TJV', 'noi-com-dien-sharp-1-8-lit-ks-181tjv', 'f3c6fd68373d42991158251ec738435b.jpg', '72e79920df66a8e477805f0fe6a68e88.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 700W&nbsp;gi&uacute;p nấu cơm nhanh, tiết kiệm thời gian</span></li>\r\n	<li><span style=\"font-size:14px\">Dung t&iacute;ch 1.8 l&iacute;t ph&ugrave; hợp nhu cầu của gia đ&igrave;nh 4 người</span></li>\r\n	<li><span style=\"font-size:14px\">L&ograve;ng nồi chống d&iacute;nh, thuận tiện trong qu&aacute; tr&igrave;nh vệ sinh</span></li>\r\n	<li><span style=\"font-size:14px\">2 m&acirc;m nhiệt&nbsp;gi&uacute;p nấu cơm nấu ch&iacute;n đều, tơi xốp</span></li>\r\n	<li><span style=\"font-size:14px\">Thời gian giữ ấm 5 giờ, thưởng thức cơm ngon chuẩn vị</span></li>\r\n	<li><span style=\"font-size:14px\">M&agrave;u sắc tinh tế, l&agrave; điểm nhấn cho kh&ocirc;ng gian bếp</span></li>\r\n</ul>\r\n', 13, 80, 1, 45, 700000, 385000, '2024-11-14 08:51:54', '1', '2024-11-14 09:13:58', '1', 1, 1),
(182, 41, 'Nồi cơm điện Sharp 1.8 lít KSH-D18V', 'noi-com-dien-sharp-1-8-lit-ksh-d18v', 'd5cf059da9b0b68c3b508d8c407cf5e6.jpg', 'aca712a48c8663cd11f922ebb4e9cb69.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Lưu &yacute;: Sản phẩm c&oacute; nhiều m&agrave;u giao m&agrave;u ngẫu nhi&ecirc;n</span></li>\r\n	<li><span style=\"font-size:14px\">Nồi c&oacute; thiết kế nắp rời, m&agrave;u sắc trang nh&atilde;, sang trọng</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất&nbsp;700 W, gi&uacute;p nấu cơm nhanh, tiết kiệm điện</span></li>\r\n	<li><span style=\"font-size:14px\">Dung t&iacute;ch 1.8 l&iacute;t th&iacute;ch hợp cho gia đ&igrave;nh 4 - 6 th&agrave;nh vi&ecirc;n</span></li>\r\n	<li><span style=\"font-size:14px\">L&ograve;ng nồi l&agrave;m từ hợp kim nh&ocirc;m cao cấp, dẫn v&agrave; giữ nhiệt tốt</span></li>\r\n	<li><span style=\"font-size:14px\">Tay cầm, ch&acirc;n đế chắc chắn, c&aacute;ch nhiệt c&aacute;ch điện an to&agrave;n</span></li>\r\n</ul>\r\n', 13, 29, 0, 15, 690000, 586500, '2024-11-14 08:52:48', '1', '2024-11-14 09:14:06', '1', 1, 1),
(183, 41, 'Nồi cơm điện tử Tefal 1.8 lít RK732168', 'noi-com-dien-tu-tefal-1-8-lit-rk732168', 'dfbaab78cd98cffe301d8bf3e57fc338.jpg', 'f8b5ed9dc978bd1de3f97b55fc280152.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Nồi cơm điện tử với c&ocirc;ng suất 750W gi&uacute;p nấu nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Dung t&iacute;ch 1.8 l&iacute;t ph&ugrave; hợp với nhu cầu của gia đ&igrave;nh nhỏ</span></li>\r\n	<li><span style=\"font-size:14px\">Bao gồm 8 chương tr&igrave;nh nấu chuy&ecirc;n dụng để bạn lựa chọn</span></li>\r\n	<li><span style=\"font-size:14px\">L&ograve;ng nồi được l&agrave;m bằng hợp kim nh&ocirc;m phủ chống d&iacute;nh, truyền nhiệt nhanh</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng nghệ giữ ấm ti&ecirc;n tiến, c&oacute; thể k&eacute;o d&agrave;i l&ecirc;n đến 12 tiếng&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Đa dạng vật dụng đi k&egrave;m, hỗ trợ tối đa qu&aacute; tr&igrave;nh nấu nướng</span></li>\r\n	<li><span style=\"font-size:14px\">Thao t&aacute;c điều khiển đơn giản th&ocirc;ng qua bảng n&uacute;t tr&ecirc;n mặt nồi</span></li>\r\n</ul>\r\n', 13, 45, 0, 30, 1290000, 903000, '2024-11-14 08:54:05', '1', '2024-11-14 09:14:13', '1', 1, 1),
(184, 41, 'Nồi cơm điện Midea 1.5 Lít MR-CM1531', 'noi-com-dien-midea-1-5-lit-mr-cm1531', '21b588661bcbb28ccadaccf878d9fa23.jpg', '5b1c14aa8a3096ae782b584a654b570b.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/noi-com-dien-midea/\">Nồi cơm điện Midea</a>&nbsp;c&ocirc;ng suất 700W nấu ch&iacute;n hiệu quả v&agrave; &iacute;t tốn điện năng</span></li>\r\n	<li><span style=\"font-size:14px\">Dung t&iacute;ch 1.5 L&iacute;t ph&ugrave; hợp với bữa cơm của 2-4 người</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng nghệ giữ ấm ti&ecirc;n tiến, gi&uacute;p cơm n&oacute;ng l&acirc;u hơn</span></li>\r\n	<li><span style=\"font-size:14px\">Nồi cơm điện hoạt động đơn giản chỉ với thanh gạt</span></li>\r\n	<li><span style=\"font-size:14px\">L&ograve;ng nồi cơm được ph&ugrave; lớp chống d&iacute;nh cao cấp, bền bỉ</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế nắp g&agrave;i ngăn nhiệt bị tho&aacute;t ra ngo&agrave;i hiệu quả</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế gọn g&agrave;ng, thu h&uacute;t với họa tiết v&ocirc; c&ugrave;ng tinh tế</span></li>\r\n</ul>\r\n', 13, 77, 0, 40, 590000, 354000, '2024-11-14 08:55:18', '1', '2024-11-14 09:14:25', '1', 1, 1),
(185, 41, 'Nồi cơm điện Happy Cook 0.6 lít HC-060 Xanh', 'noi-com-dien-happy-cook-0-6-lit-hc-060-xanh', 'c0ba6268a8bce20936f23a304b2705a0.jpg', 'ca5faadb30e38ce55f49732dc4258442.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 350W tiết kiệm điện năng</span></li>\r\n	<li><span style=\"font-size:14px\">Nồi cơm điện mini dung t&iacute;ch 0.6 l&iacute;t ph&ugrave; hợp với nhu cầu của gia đ&igrave;nh nhỏ</span></li>\r\n	<li><span style=\"font-size:14px\">Điều khiển đơn giản, dễ thao t&aacute;c với n&uacute;t gạt v&agrave; 2 đ&egrave;n hiệu</span></li>\r\n	<li><span style=\"font-size:14px\">K&egrave;m theo khay hấp rau củ, tối ưu thời gian nấu nướng</span></li>\r\n	<li><span style=\"font-size:14px\">L&ograve;ng nồi được phủ Nano Silver gi&uacute;p khử m&ugrave;i v&agrave; diệt khuẩn</span></li>\r\n	<li><span style=\"font-size:14px\">L&ograve;ng nồi chống d&iacute;nh, tr&aacute;nh t&igrave;nh trạng cơm b&aacute;m v&agrave;o đ&aacute;y nồi</span></li>\r\n	<li><span style=\"font-size:14px\">Cơ chế cảm biến nhiệt, tự động chuyển sang chế độ h&acirc;m</span></li>\r\n</ul>\r\n', 13, 16, 0, 0, 680000, 680000, '2024-11-14 08:56:34', '1', '2024-11-14 09:14:38', '1', 1, 1),
(186, 41, 'Nồi cơm mini nắp gài Coclear 0.8 lít CR6901', 'noi-com-mini-nap-gai-coclear-0-8-lit-cr6901', '12ea3216cb691d6e5e4ed6b336f6f64f.jpg', '3a6fe2a60710f90d7ba4f686ad5f40ce.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/noi-com-dien/\" target=\"_blank\">Nồi cơm điện</a>&nbsp;kiểu d&aacute;ng độc đ&aacute;o, ngộ nghĩnh tạo cảm hứng nấu cơm&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Nắp nồi c&oacute; thể th&aacute;o rời, dễ d&agrave;ng vệ sinh sau khi nấu&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">2 sừng s&aacute;ng đ&egrave;n khi nấu cho bạn dễ d&agrave;ng quan s&aacute;t trạng th&aacute;i của nồi</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 300W c&ugrave;ng dung t&iacute;ch 0.8 l&iacute;t ph&ugrave; hợp cho 1 - 2 người ăn&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">N&uacute;t gạt với đ&egrave;n b&aacute;o tiện theo d&otilde;i qu&aacute; tr&igrave;nh nấu</span></li>\r\n</ul>\r\n', 13, 32, 0, 0, 799000, 799000, '2024-11-14 08:57:41', '1', '2024-11-14 09:14:46', '1', 1, 1),
(187, 42, 'Máy ép trái cây Philips HR1811', 'may-ep-trai-cay-philips-hr1811', '63aa8e32499d18fb82b7e36ea77632a4.jpg', 'c9e0568260dd7171c5128f84b387f8d9.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/may-ep-trai-cay-philips/\">M&aacute;y &eacute;p tr&aacute;i c&acirc;y Philips</a>&nbsp;thiết kế nhỏ gọn, ph&ugrave; hợp với những kh&ocirc;ng gian bếp nhỏ</span></li>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/mua-may-ep-trai-cay-cac-chi-em-can-phan-biet-3-loai-nay.html\" target=\"_blank\">M&aacute;y &eacute;p nhanh</a>&nbsp;gi&uacute;p tiết kiệm tốt đa thời gian sử dụng</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất 300W mạnh mẽ, &eacute;p b&atilde; kh&ocirc; nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">N&uacute;t vặn 2 tốc độ &eacute;p tr&aacute;i c&acirc;y mềm, cứng sử dụng đơn giản</span></li>\r\n	<li><span style=\"font-size:14px\">Lưỡi dao, bộ lọc bằng th&eacute;p kh&ocirc;ng gỉ bền, cắt nhuyễn, lọc mịn</span></li>\r\n	<li><span style=\"font-size:14px\">Ống tiếp nguy&ecirc;n liệu lớn, &eacute;p c&aacute;c loại tr&aacute;i c&acirc;y cỡ lớn</span></li>\r\n	<li><span style=\"font-size:14px\">Chức năng tự ngắt điện khi động cơ hoạt động qu&aacute; l&acirc;u</span></li>\r\n</ul>\r\n', 13, 5, 0, 3, 1190000, 1154300, '2024-11-14 08:58:58', '1', '2024-11-14 09:15:47', '1', 1, 1),
(188, 42, 'Máy ép trái cây Sunhouse SHD5520', 'may-ep-trai-cay-sunhouse-shd5520', 'ba3e25c249e5dafba0c22d6407c624bd.jpg', '7ca9766002bf932dab8f13cc8810312e.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/may-ep-trai-cay/\">M&aacute;y &eacute;p tr&aacute;i c&acirc;y</a>&nbsp;c&ocirc;ng suất 260W &eacute;p được hầu hết c&aacute;c loại hoa quả từ mềm tới cứng</span></li>\r\n	<li><span style=\"font-size:14px\">Lưới lọc lớn gấp đ&ocirc;i lưới lọc th&ocirc;ng thường gi&uacute;p &eacute;p nước nhanh hơn</span></li>\r\n	<li><span style=\"font-size:14px\">Lưỡi xay &eacute;p bằng inox si&ecirc;u bền gi&uacute;p &eacute;p hiệu quả, an to&agrave;n cho sức khỏe</span></li>\r\n	<li><span style=\"font-size:14px\">Ch&acirc;n đế chống trượt gi&uacute;p m&aacute;y b&aacute;m chắc, kh&ocirc;ng bị rung lắc khi vận h&agrave;nh</span></li>\r\n	<li><span style=\"font-size:14px\">Điều chỉnh tốc độ bằng n&uacute;m xoay tr&ecirc;n th&acirc;n m&aacute;y, tiện lợi v&agrave; đơn giản</span></li>\r\n</ul>\r\n', 13, 59, 0, 45, 999000, 549450, '2024-11-14 09:00:01', '1', '2024-11-14 09:15:53', '1', 1, 1),
(189, 42, 'Máy ép trái cây Panasonic MJ-CS100WRA', 'may-ep-trai-cay-panasonic-mj-cs100wra', 'ac473686e53c79b933e3866bd8c1df9b.jpg', 'bf6b6cdd0944abd547e1e3ea17e50fc9.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Thiết kế m&aacute;y &eacute;p nước tr&aacute;i c&acirc;y nhỏ gọn với gam m&agrave;u trắng trang nh&atilde;, hiện đại</span></li>\r\n	<li><span style=\"font-size:14px\">M&aacute;y &eacute;p nhanh, tối ưu lượng nước &eacute;p với c&ocirc;ng suất tối đa 400W</span></li>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/may-ep-trai-cay-panasonic/\">M&aacute;y &eacute;p tr&aacute;i c&acirc;y Panasonic</a>&nbsp;thiết kế tay cầm d&aacute;ng vu&ocirc;ng tạo cảm gi&aacute;c dễ d&agrave;ng cầm nắm</span></li>\r\n	<li><span style=\"font-size:14px\">Cốc chứa nước &eacute;p được h&atilde;ng t&iacute;ch hợp vừa vặn b&ecirc;n trong m&aacute;y</span></li>\r\n	<li><span style=\"font-size:14px\">Điều khiển 2 tốc độ, t&ugrave;y chỉnh cho c&aacute;c nguy&ecirc;n liệu kh&aacute;c nhau</span></li>\r\n	<li><span style=\"font-size:14px\">C&aacute;c bộ phận của m&aacute;y &eacute;p dễ vệ sinh v&agrave; tiện lợi với m&aacute;y rửa b&aacute;t</span></li>\r\n</ul>\r\n', 13, 6, 1, 0, 1780000, 1780000, '2024-11-14 09:17:13', '1', '2024-11-14 09:17:13', '1', 1, 1),
(190, 42, 'Máy ép chậm Bear YZJ-D01Y6', 'may-ep-cham-bear-yzj-d01y6', '9b94d81bfd89254eeebdd5baf7e0ff1b.jpg', '3cbea86e6905646a23db351fa824a992.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\"><a href=\"https://www.nguyenkim.com/ep-trai-cay-bear/\" target=\"_blank\">M&aacute;y &eacute;p chậm Bear</a>&nbsp;sở hữu thiết kế hiện đại, m&agrave;u bạc sang trọng</span></li>\r\n	<li><span style=\"font-size:14px\">Vắt kiệt b&atilde; đến 98% giữ lại đầy đủ vitamin v&agrave; dưỡng chất</span></li>\r\n	<li><span style=\"font-size:14px\">C&ocirc;ng suất hoạt động 100W vắt &eacute;p triệt để nhanh ch&oacute;ng</span></li>\r\n	<li><span style=\"font-size:14px\">Dung t&iacute;ch b&igrave;nh chứa 1 l&iacute;t, dung t&iacute;ch chứa b&atilde; 0.7 l&iacute;t</span></li>\r\n	<li><span style=\"font-size:14px\">Nước &eacute;p nguy&ecirc;n chất thơm ngon, kh&ocirc;ng t&aacute;ch nước</span></li>\r\n	<li><span style=\"font-size:14px\">Ống tiếp nguy&ecirc;n liệu lớn dễ d&agrave;ng vắt &eacute;p rau củ miếng lớn</span></li>\r\n	<li><span style=\"font-size:14px\">Chất liệu an to&agrave;n cho sức khỏe người d&ugrave;ng</span></li>\r\n</ul>\r\n', 13, 16, 3, 5, 2590000, 2460500, '2024-11-14 09:18:14', '1', '2024-11-14 09:18:14', '1', 1, 1),
(191, 43, 'Túi zipper kokusai - size M', 'tui-zipper-kokusai-size-m', '18cac6064ff52678e0f3203e4aaaf0f5.jpg', '08c5ecb884029736dfb59ecc3549f860.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Gi&uacute;p bảo quản thực phẩm tốt hơn</span></li>\r\n	<li><span style=\"font-size:14px\">Sử dụng ở nhiệt độ -40&deg;C đến 120&deg;C</span></li>\r\n	<li><span style=\"font-size:14px\">C&oacute; kh&oacute;a zip tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Chống thấm tốt</span></li>\r\n</ul>\r\n', 14, 200, 0, 0, 35000, 35000, '2024-11-14 09:22:10', '1', '2024-11-14 09:22:10', '1', 1, 1),
(192, 43, 'Túi zipper Kokusai - size XL (28CMX35CM)', 'tui-zipper-kokusai-size-xl-28cmx35cm', '2de0dc30c8f88c8ad8166d5a2d08da62.jpg', '4387002ac2ef8875eabd2e3104e6fe40.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Gi&uacute;p bảo quản thực phẩm tốt hơn</span></li>\r\n	<li><span style=\"font-size:14px\">Sử dụng ở nhiệt độ -40&deg;C đến 120&deg;C</span></li>\r\n	<li><span style=\"font-size:14px\">C&oacute; kh&oacute;a zip tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Chống thấm tốt</span></li>\r\n</ul>\r\n', 14, 40, 0, 0, 40000, 40000, '2024-11-14 09:23:00', '1', '2024-11-14 09:23:00', '1', 0, 1),
(193, 43, 'Túi zip Inochi Shinshen 1L có khóa kéo', 'tui-zip-inochi-shinshen-1l-co-khoa-keo', 'cd520ba8520b5960112982bb55692eef.jpg', '3775d8720b733449e3b6251a80845d00.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Gi&uacute;p bảo quản thực phẩm tốt hơn</span></li>\r\n	<li><span style=\"font-size:14px\">K&iacute;ch thước t&uacute;i: 173 x 248 mm&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Sử dụng ở nhiệt độ -40&deg;C đến 100&deg;C</span></li>\r\n	<li><span style=\"font-size:14px\">C&oacute; kh&oacute;a zip tiện lợi với&nbsp;20 t&uacute;i/hộp</span></li>\r\n	<li><span style=\"font-size:14px\">Kh&oacute;a k&eacute;o miệng t&uacute;i chắc chắn</span></li>\r\n	<li><span style=\"font-size:14px\">Ghi ch&uacute; ng&agrave;y lưu trữ l&ecirc;n mặt t&uacute;i</span></li>\r\n	<li><span style=\"font-size:14px\">Sản phẩm dẻo dai, co gi&atilde;n tốt v&agrave; kh&oacute; r&aacute;ch</span></li>\r\n	<li><span style=\"font-size:14px\">Th&agrave;nh phần nhựa an to&agrave;n v&agrave; th&acirc;n thiện với m&ocirc;i trường</span></li>\r\n</ul>\r\n', 14, 60, 0, 3, 50000, 48500, '2024-11-14 09:23:59', '1', '2024-11-14 09:23:59', '1', 1, 1),
(194, 43, 'Túi zip Inochi Shinshen 1L có khóa kéo đáy rộng', 'tui-zip-inochi-shinshen-1l-co-khoa-keo-day-rong', '6aa34f739bec28806262360b363da2d1.jpg', 'd9f68ca9646910d5faad28801fc40b83.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Gi&uacute;p bảo quản thực phẩm tốt hơn</span></li>\r\n	<li><span style=\"font-size:14px\">K&iacute;ch thước t&uacute;i: 190 x 200 mm&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Sử dụng ở nhiệt độ -40&deg;C đến 100&deg;C</span></li>\r\n	<li><span style=\"font-size:14px\">C&oacute; kh&oacute;a zip tiện lợi với&nbsp;20 t&uacute;i/hộp</span></li>\r\n	<li><span style=\"font-size:14px\">Kh&oacute;a k&eacute;o miệng t&uacute;i chắc chắn, c&oacute; đ&aacute;y mở rộng</span></li>\r\n	<li><span style=\"font-size:14px\">Ghi ch&uacute; ng&agrave;y lưu trữ l&ecirc;n mặt t&uacute;i v&ocirc; c&ugrave;ng tiện lợi</span></li>\r\n	<li><span style=\"font-size:14px\">Sản phẩm dẻo dai, co gi&atilde;n tốt v&agrave; kh&oacute; r&aacute;ch</span></li>\r\n	<li><span style=\"font-size:14px\">Th&agrave;nh phần nhựa an to&agrave;n v&agrave; th&acirc;n thiện với m&ocirc;i trường</span></li>\r\n</ul>\r\n', 14, 44, 0, 0, 45000, 45000, '2024-11-14 09:24:58', '1', '2024-11-14 09:24:58', '1', 1, 1),
(195, 44, 'Đĩa TT Luminarc Diwali Starry Night 19 cm', 'dia-tt-luminarc-diwali-starry-night-19-cm', '76706230b886d2ce338b954ced247ada.jpg', 'ad84d74fcf6a3ee9a8fe31c19f94d0a4.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Đĩa thủy tinh</span></li>\r\n	<li><span style=\"font-size:14px\">Đường k&iacute;nh 19 cm</span></li>\r\n	<li><span style=\"font-size:14px\">Chống b&aacute;m bụi</span></li>\r\n	<li><span style=\"font-size:14px\">Dễ ch&ugrave;i rửa</span></li>\r\n</ul>\r\n', 14, 55, 0, 0, 55000, 55000, '2024-11-14 09:26:25', '1', '2024-11-14 09:26:25', '1', 1, 1),
(196, 44, 'Đĩa TT Luminarc Diwali Marble 19 cm', 'dia-tt-luminarc-diwali-marble-19-cm', '8760c3d83a9c0e9de23651775443408b.jpg', '06a3336826e9c1ea9f9a959e8e4387d1.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Đĩa thủy tinh</span></li>\r\n	<li><span style=\"font-size:14px\">Đường k&iacute;nh 19 cm</span></li>\r\n	<li><span style=\"font-size:14px\">Chống b&aacute;m bụi</span></li>\r\n	<li><span style=\"font-size:14px\">Dễ ch&ugrave;i rửa</span></li>\r\n</ul>\r\n', 14, 24, 0, 5, 40000, 38000, '2024-11-14 09:27:28', '1', '2024-11-14 09:27:28', '1', 0, 1),
(197, 44, 'Đĩa sâu TT Luminarc Diwali Starry Night 20 cm', 'dia-sau-tt-luminarc-diwali-starry-night-20-cm', '9f5c9f6b87b1ad902abe916d88cd1452.jpg', '25b72c1310f64de0a066b415d70c4ad8.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Đĩa s&acirc;u thủy tinh</span></li>\r\n	<li><span style=\"font-size:14px\">Đường k&iacute;nh 20 cm</span></li>\r\n	<li><span style=\"font-size:14px\">Chống b&aacute;m bụi</span></li>\r\n	<li><span style=\"font-size:14px\">Dễ ch&ugrave;i rửa</span></li>\r\n</ul>\r\n', 14, 33, 0, 10, 69000, 62100, '2024-11-14 09:28:24', '1', '2024-11-14 09:28:24', '1', 1, 1),
(198, 45, 'Bộ 4 sạn gỗ dừa Ohi@ma', 'bo-4-san-go-dua-ohi-ma', '183cc656005534520d5c44511ca4851a.jpg', 'c2deb039b32bf6c24fc55e43bd0c4b58.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Chất liệu gỗ tự nhi&ecirc;n</span></li>\r\n	<li><span style=\"font-size:14px\">An to&agrave;n cho sức khỏe</span></li>\r\n	<li><span style=\"font-size:14px\">Hạn chế nấm mốc vi khuẩn</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế nhỏ gọn, đẹp mắt</span></li>\r\n</ul>\r\n', 14, 40, 1, 5, 139000, 132050, '2024-11-14 09:30:15', '1', '2024-11-14 09:30:15', '1', 1, 1),
(199, 45, 'Hủ TT Herevin tròn nắp Deco 1L', 'hu-tt-herevin-tron-nap-deco-1l', '25808d76400f784032960ed8174ae3f5.jpg', '0785ef71df98e3c9ccf922b648ba048e.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Kiểu d&aacute;ng trang nh&atilde;, sang trọng</span></li>\r\n	<li><span style=\"font-size:14px\">Sản phẩm được l&agrave;m từ nhựa cao cấp</span></li>\r\n	<li><span style=\"font-size:14px\">Sản phẩm gọn nhẹ, dễ d&agrave;ng th&aacute;o mở v&agrave; vệ sinh</span></li>\r\n	<li><span style=\"font-size:14px\">Phần th&acirc;n được thiết kế vừa vặn, hạn chế trơn trượt</span></li>\r\n	<li><span style=\"font-size:14px\">An to&agrave;n với người sử dụng, th&acirc;n thiện với m&ocirc;i trường</span></li>\r\n	<li><span style=\"font-size:14px\">Nắp hộp chắc chắn, tr&aacute;nh sự x&acirc;m nhập của vi khuẩn</span></li>\r\n	<li><span style=\"font-size:14px\">Chất liệu thủy tinh trong suốt, sạch sẽ, bền đẹp v&agrave; an to&agrave;n</span></li>\r\n</ul>\r\n', 14, 30, 0, 0, 65000, 65000, '2024-11-14 09:31:24', '1', '2024-11-14 09:31:24', '1', 1, 1),
(200, 45, 'DỤNG CỤ MÀI DAO LAFONTE - 000921', 'dung-cu-mai-dao-lafonte-000921', 'b3117c17d8b87857c446c5579d217fc6.jpg', 'ccf3f1429541b764870fa836fded81b5.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Vị tr&iacute; 1 m&agrave;i nhẵn th&ocirc;, vị tr&iacute; 2 để m&agrave;i mịn</span></li>\r\n	<li><span style=\"font-size:14px\">Kh&ocirc;ng rửa m&aacute;y trong nước</span></li>\r\n	<li><span style=\"font-size:14px\">Kh&ocirc;ng sử dụng m&agrave;i lưỡi cưa hoặc k&eacute;o</span></li>\r\n	<li><span style=\"font-size:14px\">Chất liệu ABS, TPE, kim cương, Ceramic,th&eacute;p kh&ocirc;ng gỉ</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế cầm tay chắc chắn tiện lợi</span></li>\r\n</ul>\r\n', 14, 46, 0, 0, 280000, 280000, '2024-11-14 09:32:25', '1', '2024-11-14 09:32:25', '1', 1, 1),
(201, 45, 'Dao gọt Delaware - 3000389', 'dao-got-delaware-3000389', 'fcf9cf02b62a04a5787a5e8c8ad4d306.jpg', '89bee1662b03482d41086265c6fca7f0.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:14px\">Lưỡi th&eacute;p kh&ocirc;ng gỉ, c&aacute;n gỗ</span></li>\r\n	<li><span style=\"font-size:14px\">Sắc b&eacute;n, cầm chắc tay</span></li>\r\n	<li><span style=\"font-size:14px\">C&oacute; độ bền cao</span></li>\r\n	<li><span style=\"font-size:14px\">K&iacute;ch thước: 31 x 3 x 1,5 (cm)</span></li>\r\n</ul>\r\n', 14, 40, 0, 12, 280000, 246400, '2024-11-14 09:33:14', '1', '2024-11-14 09:33:14', '1', 1, 1),
(202, 45, 'CÀ MEN ZOJIRUSHI SW-FCE75', 'ca-men-zojirushi-sw-fce75', 'ef3a61187933136cefbd465a90fb427f.jpg', '408fe2614f0b1fbab45c396882a40fc8.jpg', '', '<h2><span style=\"font-size:16px\">Đặc điểm nổi bật</span></h2>\r\n\r\n<ul>\r\n	<li>C<span style=\"font-size:14px\">hất liệu th&eacute;p kh&ocirc;ng gỉ giữ nhiệt tốt dễ ch&ugrave;i rửa</span></li>\r\n	<li><span style=\"font-size:14px\">Nắp đậy chắc chắn kh&ocirc;ng sợ đổ, chống r&ograve; gỉ</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế nhỏ gọn, tiện lợi dễ mang theo&nbsp;</span></li>\r\n	<li><span style=\"font-size:14px\">Thiết kế miệng rộng c&oacute; thể m&uacute;c ăn trực tiếp</span></li>\r\n	<li><span style=\"font-size:14px\">C&aacute;ch nhiệt ch&acirc;n kh&ocirc;ng gi&uacute;p bảo quản đồ ăn n&oacute;ng lạnh&nbsp;</span></li>\r\n</ul>\r\n', 14, 70, 5, 0, 790000, 790000, '2024-11-14 09:34:06', '1', '2024-11-17 20:34:25', '86', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_province`
--

CREATE TABLE `db_province` (
  `id` int(5) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `db_province`
--

INSERT INTO `db_province` (`id`, `name`, `type`) VALUES
(1, 'Thành phố Hà Nội', 'Thành phố Trung ương'),
(2, 'Tỉnh Hà Giang', 'Tỉnh'),
(4, 'Tỉnh Cao Bằng', 'Tỉnh'),
(6, 'Tỉnh Bắc Kạn', 'Tỉnh'),
(8, 'Tỉnh Tuyên Quang', 'Tỉnh'),
(10, 'Tỉnh Lào Cai', 'Tỉnh'),
(11, 'Tỉnh Điện Biên', 'Tỉnh'),
(12, 'Tỉnh Lai Châu', 'Tỉnh'),
(14, 'Tỉnh Sơn La', 'Tỉnh'),
(15, 'Tỉnh Yên Bái', 'Tỉnh'),
(17, 'Tỉnh Hoà Bình', 'Tỉnh'),
(19, 'Tỉnh Thái Nguyên', 'Tỉnh'),
(20, 'Tỉnh Lạng Sơn', 'Tỉnh'),
(22, 'Tỉnh Quảng Ninh', 'Tỉnh'),
(24, 'Tỉnh Bắc Giang', 'Tỉnh'),
(25, 'Tỉnh Phú Thọ', 'Tỉnh'),
(26, 'Tỉnh Vĩnh Phúc', 'Tỉnh'),
(27, 'Tỉnh Bắc Ninh', 'Tỉnh'),
(30, 'Tỉnh Hải Dương', 'Tỉnh'),
(31, 'Thành phố Hải Phòng', 'Thành phố Trung ương'),
(33, 'Tỉnh Hưng Yên', 'Tỉnh'),
(34, 'Tỉnh Thái Bình', 'Tỉnh'),
(35, 'Tỉnh Hà Nam', 'Tỉnh'),
(36, 'Tỉnh Nam Định', 'Tỉnh'),
(37, 'Tỉnh Ninh Bình', 'Tỉnh'),
(38, 'Tỉnh Thanh Hóa', 'Tỉnh'),
(40, 'Tỉnh Nghệ An', 'Tỉnh'),
(42, 'Tỉnh Hà Tĩnh', 'Tỉnh'),
(44, 'Tỉnh Quảng Bình', 'Tỉnh'),
(45, 'Tỉnh Quảng Trị', 'Tỉnh'),
(46, 'Tỉnh Thừa Thiên Huế', 'Tỉnh'),
(48, 'Thành phố Đà Nẵng', 'Thành phố Trung ương'),
(49, 'Tỉnh Quảng Nam', 'Tỉnh'),
(51, 'Tỉnh Quảng Ngãi', 'Tỉnh'),
(52, 'Tỉnh Bình Định', 'Tỉnh'),
(54, 'Tỉnh Phú Yên', 'Tỉnh'),
(56, 'Tỉnh Khánh Hòa', 'Tỉnh'),
(58, 'Tỉnh Ninh Thuận', 'Tỉnh'),
(60, 'Tỉnh Bình Thuận', 'Tỉnh'),
(62, 'Tỉnh Kon Tum', 'Tỉnh'),
(64, 'Tỉnh Gia Lai', 'Tỉnh'),
(66, 'Tỉnh Đắk Lắk', 'Tỉnh'),
(67, 'Tỉnh Đắk Nông', 'Tỉnh'),
(68, 'Tỉnh Lâm Đồng', 'Tỉnh'),
(70, 'Tỉnh Bình Phước', 'Tỉnh'),
(72, 'Tỉnh Tây Ninh', 'Tỉnh'),
(74, 'Tỉnh Bình Dương', 'Tỉnh'),
(75, 'Tỉnh Đồng Nai', 'Tỉnh'),
(77, 'Tỉnh Bà Rịa - Vũng Tàu', 'Tỉnh'),
(79, 'Thành phố Hồ Chí Minh', 'Thành phố Trung ương'),
(80, 'Tỉnh Long An', 'Tỉnh'),
(82, 'Tỉnh Tiền Giang', 'Tỉnh'),
(83, 'Tỉnh Bến Tre', 'Tỉnh'),
(84, 'Tỉnh Trà Vinh', 'Tỉnh'),
(86, 'Tỉnh Vĩnh Long', 'Tỉnh'),
(87, 'Tỉnh Đồng Tháp', 'Tỉnh'),
(89, 'Tỉnh An Giang', 'Tỉnh'),
(91, 'Tỉnh Kiên Giang', 'Tỉnh'),
(92, 'Thành phố Cần Thơ', 'Thành phố Trung ương'),
(93, 'Tỉnh Hậu Giang', 'Tỉnh'),
(94, 'Tỉnh Sóc Trăng', 'Tỉnh'),
(95, 'Tỉnh Bạc Liêu', 'Tỉnh'),
(96, 'Tỉnh Cà Mau', 'Tỉnh');

-- --------------------------------------------------------

--
-- Table structure for table `db_slider`
--

CREATE TABLE `db_slider` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `link` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `img` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `created_by` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Supper Admin',
  `modified` datetime NOT NULL,
  `modified_by` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Supper Admin',
  `trash` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_slider`
--

INSERT INTO `db_slider` (`id`, `name`, `link`, `img`, `created`, `created_by`, `modified`, `modified_by`, `trash`, `status`) VALUES
(8, 'slide home', 'slide-home', 'thu-tuc-nhap-khau-do-gia-dung-nha-bep1.png', '2024-11-14 08:23:37', '1', '2024-11-14 08:23:37', '1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_user`
--

CREATE TABLE `db_user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `role` int(11) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` int(1) NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(255) NOT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `trash` int(1) NOT NULL DEFAULT 1,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_user`
--

INSERT INTO `db_user` (`id`, `fullname`, `username`, `password`, `role`, `email`, `gender`, `phone`, `address`, `img`, `created`, `trash`, `status`) VALUES
(1, 'ADMIN', 'admin', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1, 'admin@gmail.com', 1, '0399999999', 'HCM', 'user-group.png', '2024-09-20 09:16:16', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_usergroup`
--

CREATE TABLE `db_usergroup` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `trash` tinyint(1) NOT NULL DEFAULT 1,
  `access` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `db_usergroup`
--

INSERT INTO `db_usergroup` (`id`, `name`, `created`, `created_by`, `modified`, `modified_by`, `trash`, `access`, `status`) VALUES
(1, 'Toàn quyền', '2024-09-20 23:29:15', 1, '2024-09-20 23:29:15', 4, 1, 1, 1),
(2, 'Nhân viên', '2024-09-20 23:29:21', 1, '2024-09-20 23:29:21', 4, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `db_category`
--
ALTER TABLE `db_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_config`
--
ALTER TABLE `db_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_contact`
--
ALTER TABLE `db_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_content`
--
ALTER TABLE `db_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_customer`
--
ALTER TABLE `db_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_discount`
--
ALTER TABLE `db_discount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_district`
--
ALTER TABLE `db_district`
  ADD PRIMARY KEY (`id`),
  ADD KEY `matp` (`provinceid`);

--
-- Indexes for table `db_order`
--
ALTER TABLE `db_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerid` (`customerid`),
  ADD KEY `province` (`province`),
  ADD KEY `district` (`district`),
  ADD KEY `province_2` (`province`),
  ADD KEY `district_2` (`district`),
  ADD KEY `province_3` (`province`),
  ADD KEY `district_3` (`district`);

--
-- Indexes for table `db_orderdetail`
--
ALTER TABLE `db_orderdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `productid` (`productid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indexes for table `db_producer`
--
ALTER TABLE `db_producer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_product`
--
ALTER TABLE `db_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producer` (`producer`),
  ADD KEY `catid` (`catid`);

--
-- Indexes for table `db_province`
--
ALTER TABLE `db_province`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_slider`
--
ALTER TABLE `db_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_user`
--
ALTER TABLE `db_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role` (`role`);

--
-- Indexes for table `db_usergroup`
--
ALTER TABLE `db_usergroup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db_category`
--
ALTER TABLE `db_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `db_config`
--
ALTER TABLE `db_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_contact`
--
ALTER TABLE `db_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `db_content`
--
ALTER TABLE `db_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `db_customer`
--
ALTER TABLE `db_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `db_discount`
--
ALTER TABLE `db_discount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `db_order`
--
ALTER TABLE `db_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `db_orderdetail`
--
ALTER TABLE `db_orderdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `db_producer`
--
ALTER TABLE `db_producer`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `db_product`
--
ALTER TABLE `db_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `db_slider`
--
ALTER TABLE `db_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `db_user`
--
ALTER TABLE `db_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `db_usergroup`
--
ALTER TABLE `db_usergroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `db_district`
--
ALTER TABLE `db_district`
  ADD CONSTRAINT `db_district_ibfk_1` FOREIGN KEY (`provinceid`) REFERENCES `db_province` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `db_order`
--
ALTER TABLE `db_order`
  ADD CONSTRAINT `db_order_ibfk_2` FOREIGN KEY (`province`) REFERENCES `db_province` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_order_ibfk_3` FOREIGN KEY (`district`) REFERENCES `db_district` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `db_order_ibfk_4` FOREIGN KEY (`customerid`) REFERENCES `db_customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `db_orderdetail`
--
ALTER TABLE `db_orderdetail`
  ADD CONSTRAINT `db_orderdetail_ibfk_2` FOREIGN KEY (`productid`) REFERENCES `db_product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `db_orderdetail_ibfk_3` FOREIGN KEY (`orderid`) REFERENCES `db_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `db_product`
--
ALTER TABLE `db_product`
  ADD CONSTRAINT `db_product_ibfk_1` FOREIGN KEY (`catid`) REFERENCES `db_category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `db_product_ibfk_2` FOREIGN KEY (`producer`) REFERENCES `db_producer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `db_user`
--
ALTER TABLE `db_user`
  ADD CONSTRAINT `db_user_ibfk_1` FOREIGN KEY (`role`) REFERENCES `db_usergroup` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


CREATE TABLE `db_imports` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,        -- ID tự tăng
    `product_id` INT(11) NOT NULL,               -- ID sản phẩm (mối quan hệ với bảng products)
    `product_name` VARCHAR(255) NOT NULL,         -- Ten sản phẩm
    `product_categoryId` INT(11) NOT NULL,          -- ID danh muc
    `product_categoryName` VARCHAR(255) NOT NULL,   -- Ten danh muc
    `import_code` VARCHAR(255) NOT NULL,         -- Mã nhập hàng
    `image` VARCHAR(255) NULL,                   -- Hình ảnh sản phẩm
    `quantity` INT(11) NOT NULL,                 -- Số lượng nhập
    `import_date` DATETIME NOT NULL,             -- Ngày nhập
    `trash` tinyint(1) NOT NULL DEFAULT 1,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert data into db_imports table
INSERT INTO `db_imports` (`product_id`, `product_name`, `product_categoryId`, `product_categoryName`, `import_code`, `image`, `quantity`, `import_date`, `trash`, `status`) VALUES
(166, 'Bếp hồng ngoại đơn Sunhouse SHD6011', 36, 'Bếp', 'IMPORT001', '32061d99280655c10ffcf4b49d6761b7.jpg', 100, '2024-11-14 08:30:00', 1, 1),
(167, 'Bếp hồng ngoại đôi Sanaky SNK-201HGW', 36, 'Bếp', 'IMPORT002', '8c6f704965f5d9355facd4fafc25a07b.jpg', 50, '2024-11-14 08:31:00', 1, 1),
(168, 'Bếp hồng ngoại đơn Sunhouse SHD6017', 36, 'Bếp', 'IMPORT003', '581385930b6cc4a1602b07ab53169a5c.jpg', 200, '2024-11-14 08:32:00', 1, 1);

